#include <iostream>
#include <string>
using namespace std;

// print each character in a given string
void traverse(string x);
int main()
{
    string str = "ABC";
    traverse(str);
    return 0;
}

void traverse(string x)
{
    for(int i=0; i < x.length();i++)
    {
        cout << x[i] << endl;
    }
}
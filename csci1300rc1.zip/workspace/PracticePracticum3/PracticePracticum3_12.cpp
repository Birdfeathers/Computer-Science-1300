#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int CountVowels(string str)
{
    int length = str.length();
    if(length == 0) return -1;
    int numvowels = 0;
    for(int i= 0; i < length ; i++)
    {
       if(str[i]=='i'|| str[i] == 'e' || str[i] == 'o' || str[i] == 'u' || str[i]
       == 'a') numvowels++;
        if(str[i]=='I'|| str[i] == 'E' || str[i] == 'O' || str[i] == 'U' || str[i]
       == 'A') numvowels++;
    }
    return numvowels;
}

int writeVowels(string file_name, string arr[], int size)
{
    ofstream outfile;
    outfile.open(file_name);
    int lineswritten =0;
    for(int i=0; i < size; i++)
    {
        string string1 = arr[i];
        int length = string1.length();
        if(length != 0)
        {
            int numvowel = CountVowels(string1);
            outfile << string1 << "," <<numvowel<<endl;
            lineswritten++;
        }
    }
    return lineswritten;
}

int main()
{
   string words[] = {"hello","", "WORLD"};
   cout<<writeVowels("vowels.txt", words, 3);
}
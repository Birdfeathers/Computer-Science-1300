#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;


int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

int PrintStudents(string file_name, int minscore, string output_file)
{
    ifstream file;
    file.open(file_name);
    if(!file.is_open())return -1;
    string line;
    int counter = 0;
    ofstream outfile;
    outfile.open(output_file);
    while(getline(file, line))
    {
        counter++;
        string array1[3];
        split(line, ',', array1, 3);
        if(stof(array1[1]) >= minscore)
        {
            outfile << array1[0] << "," << array1[2] << endl;
        }
    }
    return counter;
    
}

int main()
{
    cout << PrintStudents("students.txt", 80, "newstudents.txt");
}
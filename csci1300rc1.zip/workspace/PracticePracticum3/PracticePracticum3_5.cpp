#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

void findDuplicate (int array1[ ], int size)
{
    bool foundvariable = false;
    for(int i =0; i < size ; i++)
    {
        int check = array1[i];
        for(int j = i+1; j < size; j++)
        {
            if(check == array1[j])
            {
                cout <<check;
                foundvariable = true;
            }
        }
    }
    if(foundvariable == false) cout << -1;
}

int main()
{
    int array[]= {2,3,5,6,11,20,4,8,4,9};
    findDuplicate(array, 10);
    int array1[] = {1,3,5,6,7,8,2,9} ;
    findDuplicate(array1, 8);
}

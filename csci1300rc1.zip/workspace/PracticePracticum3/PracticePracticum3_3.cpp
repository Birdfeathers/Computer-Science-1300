#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

bool IsPrime(int number)
{
   bool truthValue = true;
   if(number < 2) truthValue = false;
   for(int i = 2; i < number; i++)
   {
       if(number % i == 0)truthValue = false;
   }
   return truthValue;
}


int countPrimes(int array[], int size)
{
    int counter = 0;
    for(int i = 0; i < size; i++)
    {
        if(IsPrime(array[i])) counter ++;
    }
    return counter;
}

int main()
{
    // int array[] ={1, 2, 3, 4, 5, 7, 10, 12};
    // cout<< countPrimes(array, 8);
    	
    int array[10] = {2, 3, 5, 7, 9, 11, 13, 17, 19, 81};
    primes_count = countPrimes(array, 3);
}
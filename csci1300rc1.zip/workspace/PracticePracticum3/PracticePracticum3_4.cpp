#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int diagonalSum(int arr[][3], int row)
{
    int total = arr[0][0] + arr[1][1] + arr[2][2];
    return total;
}

int main()
{
    int arr[3][3]= {{1, 4, -6}, {17, -23, 3}, {-5, 15, 5}};
    cout << diagonalSum(arr, 3);
}
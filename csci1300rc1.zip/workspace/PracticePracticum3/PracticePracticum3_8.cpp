#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

void printTotalMedals(string sports[], int numgolds[], int numsilvers[], int numbronze[], int size)
{
    if(size < 1)cout << "Invalid size. Size must be at least 1.";
    else
    {
        for(int i = 0; i < size; i++)
        {
            int total = numgolds[i] + numsilvers[i] + numbronze[i];
            cout << sports[i] << ": " << total << endl;
        
        }
    }
}


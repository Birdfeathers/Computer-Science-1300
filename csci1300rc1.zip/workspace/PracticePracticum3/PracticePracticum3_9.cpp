#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

bool similarity(int arr1[ ], int size1, int arr2[], int size2)
{
    if(size1 != size2) return false;
    for(int i= 0; i < size1; i++)
    {
        if(arr1[i] != arr2[i]) return false;
    }
    return true;
}

int main()
{
    int arr1[]= {1, 4, 6, 7, 23, 3};
    int arr2[] = {1, 4, 6, 7, 23, 3};
    cout << similarity(arr1, 6, arr2, 6);
}
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;


int countCharacter(string array[ ], int size, char ch)
{
    int counter = 0;
    for(int i =0 ; i < size ; i++)
    {
        string line = array[i];
        int length = line.length();
        for(int j = 0; j < length; j++)
        {
            if(line[j] == ch) counter++;
        }
    }
    return counter;
}

int main()
{
    string array[] = {"elephant", "english", "elegant", "america", "united", "apple"};
    char ch = 'e';
    cout << countCharacter(array, 6, ch);
}
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

bool similarity(int arr1[][3], int row1, int arr2[][3], int row2)
{
    if(row1 != row2) return false;
    for(int i= 0; i < row1; i++)
    {
        for(int j=0; j < 3; j++)
        {
            if(arr1[i][j] != arr2[i][j]) return false;
        }
    }
    return true;
}
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

float averageTemp(string file_name)
{
    ifstream file;
    file.open(file_name);
    if(!file.is_open())return -1;
    split
}
//(check split.cpp)
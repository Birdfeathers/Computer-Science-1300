#include <iostream>
using namespace std;

void classGreeting (int classnumber);
{
   cin>> classnumber;
    cout <<"Hello, CS "<<classnumber<<" World!"<<endl;
}


classGreeting(1300)
}
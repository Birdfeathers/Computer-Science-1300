 #include <iostream>
#include <math.h>
using namespace std;

int main() {
cout << "Enter a radius: " << endl;
    float radius;
    cin >> radius;
    float volume;
    volume = (4.0/3.0) * M_PI * pow(radius, 3);
    cout << "volume: " << volume << endl;
    
    float surface_area = 4 * M_PI * radius * radius;
    cout << "surface area: " << surface_area << endl;
}
#include <iostream>
using namespace std;

string switchToLower(string string1)
{
    string string2 = "";
    int length = string1.length();
    for(int i = 0; i<length; i++)
    {
        char letter = string1[i];
        if(isdigit(letter));
        else if(letter > 40 && letter < 91)letter = letter + 32;
        string2 = string2 + letter;
    }
    return string2;
}

int main()
{
    //if('2' > 40 &&) cout << "y";
    cout << switchToLower("bEN2 ")<< endl;
}
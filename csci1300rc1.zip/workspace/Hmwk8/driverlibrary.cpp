#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Book.h"
#include "User.h"
#include "Library.h"
using namespace std;

int main()
{
    Library one;
    //cout << one.readBooks("booklist.txt")<<endl;
    //cout <<one.readRatings("ratings.txt")<<endl;
    one.readBooks("booklist.txt");
    one.readRatings("ratings.txt");
    //one.printAllBooks();
    //cout << one.getCountReadBooks("ethan")<<endl;
    //cout << fixed<<setprecision(2)<<one.calcAvgRating("The Hitchhiker's Guide To The Galaxy") << endl;
    //cout << one.addUser("g")<< endl;
    //cout << one.addUser("G")<< endl;
    //cout << one.checkOutBook("g", "Thirteen Reasons Why", 5)<<endl;
    //one.viewRatings("cynthia");
    //one.getRecommendations("johnny");
    //one.getRecommendations("amy");
    one.getRecommendations("carol");
    //one.getRecommendations("cynthia");
    
    // Library two;
    // cout << two.readBooks("booklist.txt")<<endl;
    // cout <<two.readRatings("ratings.txt")<<endl;
    // two.printAllBooks();
}
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Book.h"
#include "User.h"
#include "Library.h"
using namespace std;

string switchToLower(string string1)
{
    string string2 = "";
    int length = string1.length();
    for(int i = 0; i<length; i++)
    {
        char letter = string1[i];
        if(isdigit(letter));
        else if(letter > 40 && letter < 91)letter = letter + 32;
        string2 = string2 + letter;
    }
    return string2;
}

Library :: Library()
{
    numBooks = 0;
    numUsers = 0;
}

int Library :: readBooks(string file_name)
{
    ifstream readbook; // declares fstream variable
    readbook.open(file_name); // opens file function was fed
    if(!readbook.is_open()) return -1; // returns -1 is can't access file
    string line; // to be given the lines of code
    int booknumber = numBooks; // number of books filled so far- fill from here
    while(getline(readbook,line) && booknumber < sizeBook)// while the document isn't empty & still room
    {
        int linelength = line.length();
        string author= "", title= "";
        int i = 0;
        for(i; line[i] != ','; i++) // gets up to the comma- author's name
        {
            author = author + line[i]; // concatonates name one letter at a time
        }
        for(i++; i < linelength; i++) // continues after the comma- title
        {
            title = title + line[i]; // concatonates title
        }
        mybooks[booknumber].setAuthor(author); // puts it into author array at the book number position
        mybooks[booknumber].setTitle(title); // puts it into title array at the book number position
        booknumber++; // moves to next position in array
    }
    numBooks = booknumber;
    return booknumber; // returned how far it goes until
}

int Library :: readRatings(string file_name)
{
    ifstream ratings; // variable for ratings file
    ratings.open(file_name); // open ratings file with it's name
    if(!ratings.is_open()) return -1; // returns -1 if file could not be open
    string line; // variable to be given lines
    int user = numUsers; // sets the user it starts on with the number of users already filled
    while(getline(ratings,line)&& user < sizeUser)// while still lines to get & room in array
    {
        string name = "";
        int i = 0, linelength = line.length(), counter = 0;
        for(i; line[i] != ','; i++) // gets username before comma
        {
            name = name + line[i];// concatonates username
        }
        for(i++; i < linelength; i++) // gets scores after username
        {
            if(line[i] != ' ') // numbers are at positions where there are not spaces
            {
                string rating =  line.substr(i, 1);// the rating must be converted to a string
                int rate = stoi(rating); // next, converted to an integer
                myuser[user].setRatingAt(counter, rate); // now stored in the array
                counter++; // inc so next colmumn in array will be used for next int
            }
        }
        myuser[user].setUsername(name); // at the end the line, we can put the username in the username array
        user++; // move to next user
        //cout << name << "..." << endl; // prints names as they are added
        cout << myuser[user-1].getUsername() << "..." << endl;
        
    }
    numUsers = user;
    return user;
}

void Library :: printAllBooks()
{
    if(numBooks <= 0) cout<< "Database has not been fully initialized"<< endl; // equals zero or -1 before arrays formed
    else
    {
        cout<< "Here is a list of books"<<endl;
        for(int i=0; i < numBooks; i++)
        {
            cout << mybooks[i].getTitle() << " by " << mybooks[i].getAuthor()<< endl;// prints matching elements of arrays
        }
    }
}

int searchuser(string username, User allusers[],int numusers) // helper function for getUserReadCount
{
    for(int i = 0; i < numusers ; i++)
    {
        if(username == switchToLower(allusers[i].getUsername())) return i; // returns the index for the user once a match is found
    }
    return -1;// meaning it failed to find the username after traversing whole array
}



int Library :: getCountReadBooks(string username)
{
    int usernumber = searchuser(switchToLower(username), myuser, numUsers);
    if(numUsers == 0 || numBooks == 0)
    {
        cout << "Database has not been fully initialized"<<endl;
        return -1;
    }
    if(usernumber == -1) // helper function failed to find user
    {
        cout<< username << " does not exist in the database" << endl;
        return -2; 
    }
    int counter = 0; // counts number of books
    for(int i= 0; i < numBooks; i++)
    {
        if(myuser[usernumber].getRatingAt(i) > 0) // zero indicating they did not read the books
        {
            counter++;
        }
    }
    
    return counter;
}

int searchbook(string title, Book titles[],int books) // helper function for calcAvgRating
{
    for(int i = 0; i < books ; i++)
    {
        if(title == titles[i].getTitle()) return i; // if the title given matches the entry at the index, return the index
    }
    return -1;// meaning it failed to find the book
}

double Library :: calcAvgRating(string title)
{
    if(numUsers == 0 || numBooks == 0)
    {
        cout << "Database has not been fully initialized"<<endl;
        return -1;
    }
    int booknumber = searchbook(title, mybooks, numBooks);
    if(booknumber == -1) // meaning helper function could not find it
    {
        cout<< title << " does not exist in the database" << endl;
        return -2;
    }
    double total = 0, number= 0; //total keeps track of all ratings added together, number keeps track of number of ratings
    for(int i=0; i < numUsers; i++)
    {
        if(myuser[i].getRatingAt(booknumber) > 0) // zero indicates they haven't read it, so only nonzeros should count
        {
            total = total + myuser[i].getRatingAt(booknumber); // adding rating to total
            number++; // keeping track og number of ratings
        }
    }
    double average = total / number; //finds mean
    return average; 
}

bool Library :: addUser(string username)
{
    string usernameo = username;
    username = switchToLower(username);
    if(numUsers >= 200) //200 max amount in array
    {
        cout << "Database full" << endl;
        return false;
    }
    int usernumber = searchuser(username, myuser, numUsers);
    if(usernumber != -1)
    {
        cout << usernameo << " already exists in the database" <<endl;
        return false;
    }
    myuser[numUsers].setUsername(username);
    for(int i = 0; i < numBooks; i++)
    {
        myuser[numUsers].setRatingAt(i, 0);
    }
    numUsers++; //another user added
    return true;
}

bool Library :: checkOutBook(string username, string title, int newrating)
{
    string usernameo = username; //keep track of original username before switch to lower
    username = switchToLower(username);
    if(numUsers == 0 || numBooks == 0)
    {
        cout << "Database has not been fully initialized"<<endl;
        return false;
    }
    int usernumber = searchuser(username, myuser, numUsers);
    bool return_value = true; //don't return until other conditions are checked
    if(usernumber == -1)
    {
        cout << usernameo << " does not exist in the database" <<endl;
        return_value = false;
    }
    int booknumber = searchbook(title, mybooks, numBooks);
    if(booknumber == -1) // meaning helper function could not find it
    {
        cout<< title << " does not exist in the database" << endl;
        return_value = false;
    }
    if(newrating < 0 || newrating > 5)
    {
        cout << newrating << " is not valid" << endl;
        return_value = false;
    }
    if(return_value == false) return false;
    myuser[usernumber].setRatingAt(booknumber, newrating);
    return true;
}

void Library :: viewRatings(string username)
{
    string usernameo = username;
    username = switchToLower(username);
    if(numUsers == 0 || numBooks == 0)
    {
        cout << "Database has not been fully initialized"<<endl;
    }
    else{
    int usernumber = searchuser(username, myuser, numUsers);
    if(usernumber == -1)
    {
        cout << usernameo << " does not exist in the database" <<endl;
    }
    else{
    bool rated_books = false;
    for(int i = 0; i < numBooks; i++)
    {
        if (myuser[usernumber].getRatingAt(i) > 0) rated_books = true;
    }
    if(rated_books == false)cout << usernameo <<" has not rated any books yet" << endl;
    else
    {
        cout << "Here are the books that "<< username << " rated" << endl;
        for(int i = 0; i < numBooks; i++)
        {
            if (myuser[usernumber].getRatingAt(i) > 0)
            {
                cout << "Title : " << mybooks[i].getTitle() << endl;
                cout<< "Rating : " <<myuser[usernumber].getRatingAt(i) << endl;
                cout << "-----" << endl;
                
            }
        }
    }
    }
    }
}

bool checkread(int usernumber, int numBooks,User myuser[])
{
    bool rated_books = false;
    for(int i = 0; i < numBooks; i++)
    {
        if (myuser[usernumber].getRatingAt(i) > 0) rated_books = true;
    } 
    return rated_books;
}

void Library :: getRecommendations(string username)
{
    if(numUsers == 0 || numBooks == 0)
    {
        cout << "Database has not been fully initialized"<<endl;
    }
    else{
    int usernumber = searchuser(switchToLower(username), myuser, numUsers);
    if(usernumber == -1)
    {
        cout << username << " does not exist in the database" <<endl;
    }
    else{
    int lowest = -1;
    int lowest_SSD;
    for(int i = 0; i < numUsers; i++)
    {
        int SSD = 0;
        bool rated_books = checkread(i, numBooks, myuser);
        if(rated_books && i != usernumber)
        {
            for(int j = 0; j < numBooks; j++)
            {
                int diff = myuser[usernumber].getRatingAt(j) - myuser[i].getRatingAt(j);
                SSD = SSD + (diff * diff);// sum of squared differences
            }
            if (SSD < lowest_SSD || lowest == -1) // lowest originally at -1, so sets initial value
            {
                lowest_SSD = SSD;
                lowest = i;
            }
        }
    }
    int recommend = 0; // number of books reccomended so far
    for(int p = 0; p < numBooks && recommend < 5; p++)
    {
        if(myuser[lowest].getRatingAt(p) > 2 && myuser[usernumber].getRatingAt(p) < 1)// if one user gives it high rating and other has not read it 
        {
            if(recommend == 0) cout << "Here are the list of recommendations:" << endl;
            cout << mybooks[p].getTitle() << " by " << mybooks[p].getAuthor() << endl;
            recommend++;
        }
    }
    if(recommend == 0 ) cout << "There are no recommendations for " << username<<" at the present" << endl;
    }
    }
}
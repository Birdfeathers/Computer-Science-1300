#include <iostream>
#include <fstream>
#include <sstream>
#ifndef LIBRARY_H
#define LIBRARY_H
#include <iomanip>
#include "Book.h"
#include "User.h"
using namespace std;

class Library
{
    public:
        Library();
        int readBooks(string file_name);
        int readRatings(string file_name);
        void printAllBooks();
        int getCountReadBooks(string username);
        double calcAvgRating(string title);
        bool addUser(string username);
        bool checkOutBook(string username, string title, int newrating);
        void viewRatings(string username);
        void getRecommendations(string username);
    private:
        int numBooks;
        int numUsers;
        const int sizeBook = 200;
        const int sizeUser = 200;
        Book mybooks[200];
        User myuser[200];
        
};

#endif
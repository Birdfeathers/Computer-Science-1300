#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#ifndef FOREST_H
#define FOREST_H

class Forest
{
    public:
        void ForestMenu();
        string searchForest();
};

#endif
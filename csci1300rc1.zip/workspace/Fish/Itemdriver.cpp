#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#include "Item.h"

int main()
{
    Item Item1("apple");
    cout << Item1.getEdible() <<endl;
    cout << Item1.getName() <<endl;
    cout << Item1.getNumber() << endl;
    cout << Item1.getType()<<endl;
    Item1.setNumber(4);
    cout << Item1.getNumber() <<endl;
    cout << Item1.getFoodNumber() <<endl;
}
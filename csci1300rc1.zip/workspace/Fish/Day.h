#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Beach.h"
#include "Fish.h"
#include "Item.h"
#include "Market.h"
#include "PetStore.h"
#include "Pond.h"
#include "Tank.h"
#include "User.h"
#include "game.h"
#include "Forest.h"
#ifndef DAY_H
#define DAY_H
using namespace std;

class Day
{
    public:
        Day();
        void advanceHour(int hours);
        int getDay();
        int getHour();
        int getDrowsiness();
        int getStamina();
        int getMoney();
        int setMoney(int newmoney);
        void setDrowsiness(int newDrowsiness);
        void setStamina(int newStamina);
        int checkInventory();
        bool addItem(Item Item1);
        bool removeItem(int itemnumber);
        bool listTanks();
        void examineTank(int tankNumber);
        void addTank(Tank Tank1);
        void purchaseTank();
        void purchaseFish();
        void purchasePetItem();
        void purchaseMarket();
        void playGuessGame();
        void playJeapardyDice();
        void playMarbleRun();
        void loadGame(string textfile);
        void saveGame(string savefile);
        void oceans();
        bool hasFishingPole();
        bool placingfish(string species, char pattern);
        void ponds();
        void forests();
        void sellFish();
        void sellItems();
        int calcrank();
        int getScore();
        bool checkSave(string savefile);
    private:
        User one;
        game player;
        int guessHigh;
        int score;
        vector <Tank> mytanks;
        vector <Item> inventory;
        PetStore pet;
        Market market;
        Beach ocean;
        Pond pond;
        Forest forest;
        int hour;
        int daynumber;
        
};
#endif
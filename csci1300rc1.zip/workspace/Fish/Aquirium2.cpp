#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Beach.h"
#include "Fish.h"
#include "Item.h"
#include "Market.h"
#include "PetStore.h"
#include "Pond.h"
#include "Tank.h"
#include "User.h"
#include "Day.h"
//#include "game.h"
using namespace std;
/*sources:
1.
http://www.cplusplus.com/reference/cstdlib/rand/
#used to figure out how to seed a randomness generator with the time
2.
I used the split function to help me read in info from my files.
3. 
I used the Jeapardy dice game and Marble Run game from earlier this semester in the videogame section of the game
*/

// to play: 
//g++ -std=c++11 Fish.cpp Tank.cpp Beach.cpp Forest.cpp Item.cpp Market.cpp PetStore.cpp Pond.cpp User.cpp game.cpp Day.cpp Aquirium2.cpp

bool CheckNumber(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}

void HomeMenu(int stamina, int drowsiness, int day, int hour, int money){
    cout << "Welcome Home!" << "stamina = " << stamina << "; drowsiness = " << drowsiness << "; money = " << money <<endl;
    cout << "Day: " << day << "     Hour: " << hour << endl;
    cout << "What would you like to do next?" << endl;
    cout << "1. Examine tanks" <<endl;
    cout << "2. Sleep" << endl;
    cout << "3. Play Videogame" <<endl;
    cout << "4. Check inventory" << endl;
    cout << "5. Go out" <<endl;
    cout << "6. Save game" <<endl;
    cout << "7. Quit game" << endl;
}

void goOutMenu(){
    cout << "Where would you like to go?"<< endl;
    cout << "1. The Pet Store" <<endl;
    cout << "2. The Market" << endl;
    cout << "3. The Ocean" <<endl;
    cout << "4. The Pond" << endl; 
    cout << "5. The Forest" <<endl;
}
void petStoreMenu(){
    cout << "What would you like to do at the pet store?" << endl;
    cout << "1. Buy tank" << endl;
    cout << "2. Buy fish" << endl;
    cout << "3. Buy items" << endl;
    cout << "4. Work" << endl;
    cout << "5. Sell Fish" <<endl;
    cout << "6. Leave store" << endl;
}

void marketMenu() {
    cout << "What would you like to do at the Market?" <<endl;
    cout << "1. Buy items" <<endl;
    cout << "2. work" <<endl;
    cout << "3. Sell items" <<endl;
    cout << "4. Leave store" << endl;
}

void gameMenu(){
    cout << "Which game would you like to play?" <<endl;
    cout << "1. Number guess mind trap" <<endl;
    cout << "2. Jeapardy Dice" <<endl;
    cout << "3. Marble Run" <<endl;
    cout << "4. none" <<endl;
}

int main()
{
   cout << "Welcome to Aquirium Land! " <<endl;
   Day game;
   string choice;
   cout << "Would you like to load a saved game? (Yes/No)?" <<endl;
   cin >> choice;
   if(choice == "yes" || choice == "Yes" || choice == "Y" || choice == "y")
   {
       cout << "Type in the name of the saved file you would like to load." <<endl;
       cin >> choice;
       game.loadGame(choice);
   }
   while(choice != "stopGame")
   {
       HomeMenu(game.getStamina(),game.getDrowsiness(), game.getDay(), game.getHour(), game.getMoney());
       cin >> choice;
       if(!CheckNumber(choice))cout << "Invalid Input" << endl;
       else switch(stoi(choice)){
           case 1:
            if(game.listTanks()){
                cout << "Which tank would you like to examine?" << endl;
                cin >> choice;
                if(CheckNumber(choice)){
                    game.examineTank(stoi(choice)-1);
                   }
                 else cout << "Invalid, you may only input positive integers" <<endl;
                }
                
           break;
           case 2:
            cout << "How many hours would you like to sleep for?" << endl;
            cin >> choice;
            if(CheckNumber(choice)){
                if(choice.length() < 5){
                game.setDrowsiness(game.getDrowsiness() - 3 * stoi(choice));
                game.setStamina(game.getStamina() + 2 * stoi(choice));
                game.advanceHour(stoi(choice));
                if(game.getDrowsiness() < -10) game.setDrowsiness(-10);
                if(game.getStamina() > 10) game.setStamina(10);
                }
                else cout << "This number is too big Ian." <<endl;
            }
            else cout << "Invalid, you may only input positive integers" <<endl;
           break;
           case 3:
            cout << "How many hours would you like to play videogames for?" << endl;
            cin >> choice;
            if(CheckNumber(choice)){
                if(choice.length() < 5){
                    if(stoi(choice) == 0)cout << "You must play for at least one hour" <<endl;
                    else{
                    game.advanceHour(stoi(choice));
                    gameMenu();
                    cin >> choice;
                    if(choice == "1" )game.playGuessGame();
                    if(choice == "2") game.playJeapardyDice();
                    if(choice == "3")game.playMarbleRun();
                    }
                }
                else cout << "This number is too big Ian" <<endl;
            }
            else cout << "Invalid, you may only input positive integers" <<endl;
           break;
           case 4:
            game.setStamina(game.getStamina()+ game.checkInventory());
           break;
           case 5:
            goOutMenu();
            cin >> choice;
            if(choice == "1"){
                if(game.getHour() < 9 || game.getHour() > 18) cout << "The pet store is not currently open. Hours are between 9 and 18."<<endl;
                else{
                    while(choice != "petEnd")
                    {
                        petStoreMenu();
                        cin >> choice;
                        if(choice == "1") game.purchaseTank();
                        else if(choice == "2") game.purchaseFish();
                        else if(choice == "3") game.purchasePetItem();
                        else if(choice == "4"){
                            cout << "How many hours would you like to work at the pet Store?" << endl;
                            cin >> choice;
                            if(!CheckNumber(choice)) cout <<"Invalid input"<< endl;
                            else{
                                if(choice.length() > 4) cout << "This number is too big Ian" <<endl;
                                else if((stoi(choice) + game.getHour())> 18) cout << "You can only work until hour 18" << endl;
                                else{
                                    game.setStamina(game.getStamina() - (2 * stoi(choice)));
                                    game.advanceHour(stoi(choice));
                                    game.setMoney(game.getMoney() + (20 * stoi(choice)));
                                }
                            }
                        }
                        else if(choice == "5") game.sellFish();
                        else if(choice == "6") choice = "petEnd";
                        else cout << "Invalid input" << endl;
                    }
                }
            }
            else if(choice == "2"){
                if(game.getHour() < 7 || game.getHour() > 16) cout << "The Market is not currently open. Hours are between 7 and 16."<<endl;
                else{
                    while(choice != "marketEnd")
                    {
                        marketMenu();
                        cin >> choice;
                        if(choice == "1") game.purchaseMarket();
                        else if(choice == "2"){
                            cout << "How many hours would you like to work at the Market?" << endl;
                            cin >> choice;
                            if(!CheckNumber(choice)) cout <<"Invalid input"<< endl;
                            else{
                                if(choice.length() > 4) cout << "This number is too big Ian" <<endl;
                                else if((stoi(choice) + game.getHour())> 16) cout << "You can only work until hour 16" << endl;
                                else{
                                    game.setStamina(game.getStamina() - (stoi(choice)));
                                    game.advanceHour(stoi(choice));
                                    game.setMoney(game.getMoney() + (10 * stoi(choice)));
                                }
                            }
                        }
                        else if (choice == "3") game.sellItems();
                        else if (choice == "4") choice = "marketEnd";
                        else cout << "Invalid input" << endl; 
                }
                }
            }
            else if(choice == "3") game.oceans();
            else if(choice == "4") game.ponds();
            else if (choice == "5") game.forests();
            else cout << "Invalid input" << endl;
           break;
           case 6:
            cout << "What would you like to name your save file?" << endl;
            cin >> choice;
            if(game.checkSave(choice)){
            game.saveGame(choice);
            cout << "Game saved" <<endl;
            }
            else cout << "You cannot save to that file because it will overwrite the game." <<endl;
           break;
           case 7:
            cout << "Are you sure you want to end your game?(Yes/No)" << endl;
            cin >> choice;
            if(choice == "Yes" || choice == "yes" || choice == "y" || choice == "Y"){
                choice = "stopGame";
                cout << "See you next time." <<endl;
            }
            break;
            default:
                cout << "Invalid Input" << endl;
       }   
       if(game.getDrowsiness() >= 10 || game.getStamina() <= -10){
           cout << "You over exerted yourself and fainted. You lost this round of Aquirium land." << endl;
           choice = "stopGame";
       }
        else if((game.getDay() > 13)&& game.getScore() == 0){
            cout << "Congratulations! You completed Aquirium land!" << endl;
            cout << "Rank: " << game.calcrank() << endl;
            cout << "Would you like to continue playing(Yes/No)" << endl;
            cin >> choice;
            if(choice== "No" ||choice == "no" || choice == "n" || choice == "N")choice = "stopGame";
        }

   }
   
}   


// implent menu here, goes to different menus

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

//small fish = one space 1x1, medium fish= two adjacent spaces 1x2, large fish= three adjacent spaces 1x3
//huge fish = two rows of three adjacent spaces 2x3, gigantic fish = 3x3, epic fish = 9x3

bool checkNumber(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}



void sortArray(int array1[], int size)
{
   for(int i= 0;  i < size; i++)
   {
      int minimum = array1[i];
      int minimum_position = i;
      for(int j = i+1; j < size; j++)
      {
        if(array1[j] < minimum) 
        {
            minimum = array1[j];
            minimum_position = j;
        }
      }
      array1[minimum_position]=array1[i];
      array1[i]= minimum; 
   }
}

bool IsAdjacent(int value1, int value2) // must be in order
{
   if(value2 == value1 + 1 && value1 / 3 == value2 / 3) return true;
   return false; 
}

bool IsInColumn(int value1, int value2)//must be in order
{
  if(value2 == value1 + 3)  return true;
  return false;
}

void turnSideways(int array1[], int size, int matrix_size)
{
    for(int i = 0; i < size; i++)
    {
        int number = array1[i];
        int column = number % 3;
        int row = number / 3;
        int numrows = matrix_size / 3;
        number = column * numrows + row;
        array1[i] = number;
    }
}

bool Tank_checker(int fish_size, string orientation, int tank_size, string arrangement[81], string fish_name)
{
    //cout << arrangement[1] << "x";
    int arr[81];
    int spacenumber = 0; //keeps track of number of digits user entered
    cout << "Where would you like to put the fish?" << endl;
    cout << "Enter the numbers representing the spaces you would like to put the fish" << endl;
    for(int i = 0; spacenumber < fish_size; i++)
    {
        string value;
        cin >> value;
        if(checkNumber(value))
        {
            if(stoi(value) < tank_size)
            {
                //cout << arrangement[stoi(value)] << arrangement[1] <<"y";
                if (arrangement[stoi(value)] == "NA")
                {
                    arr[i]= stoi(value);
                    spacenumber++;
                    arrangement[stoi(value)] = fish_name;
                    //cout << arrangement[i];
                }
                else cout << "Entries must be unoccupied spaces" <<endl;
            }
            else cout << "Entries must be spaces within the tank" <<endl;
        }
        else cout << "Entries must be numbers." << endl;
    }
    sortArray(arr, fish_size);
    if(orientation == "normal"){
    if (fish_size == 2){
        if(IsAdjacent(arr[0], arr[1]))return true;
        return false;
    }
    for(int i = 0; i < fish_size- 1; i = i+ 3)
    {
        if(!IsAdjacent(arr[i], arr[i+1])|| !IsAdjacent(arr[i+1], arr[i+2])) return false;
    }
    for(int j = 0; j <= fish_size-6; j++)
    {
       //cout << "g" << arr[j] << arr[j+3] << endl;
       if(!IsInColumn(arr[j], arr[j+3]))return false;
    }
     return true;}
    if(orientation == "sideways"){
        //cout << "m";
        if(fish_size == 2){
            if(IsInColumn(arr[0], arr[1])) return true;
            return false;}
        if(fish_size == 3){
            if(IsInColumn(arr[0], arr[1])&& IsInColumn(arr[1], arr[2])) return true;
            return false;
        }
       if(fish_size == 6){
           if(!IsInColumn(arr[0], arr[2])|| !IsInColumn(arr[2],arr[4]))return false;
           if(!IsInColumn(arr[1], arr[3])|| !IsInColumn(arr[3],arr[5]))return false;
           if(!IsAdjacent(arr[0], arr[1]))return false;
           return true;
       }
        
    }

            
}

bool fish_placer(int fish_size, string orientation, int tank_size, string arrangement[81], string fish_name)
{
    if(fish_size > tank_size)
    {
        cout << "This fish is too big to fit in this tank." << endl;
        return false;
    }
    string ray[81];
    string user_response;
    bool placed_fish = false;
    while(placed_fish == false)
    {
        for(int i= 0; i < 81; i++)
        {
            ray [i] = arrangement[i];
        }
        placed_fish = Tank_checker(fish_size, orientation, tank_size, ray, fish_name);
        if(placed_fish == false)
        {
            cout << "The fish must be placed in one continuous space" << endl;
            cout << "Continue placing fish?(Yes/No)" << endl;
            cin >> user_response;
            if(user_response == "No") return false;
        }
    }
    for(int i= 0; i < 81; i++)
        {
            arrangement[i] = ray[i];
        }
    return true;
}

int main()
{
    string ray[81];
    for(int i= 0; i < 81; i++)
    {
        ray[i] = "NA";
    }
    ray[2] = "kay";
    //cout<< ray[13];
    //for(int i = 0; i < 27; i++) cout<< ray[i] << " ";
    //  cout <<Tank_checker(27, 81, ray, "fishy");
    cout << fish_placer(6, "sideways", 81, ray, "fishy");
    for(int i = 0; i < 27; i++) cout<< ray[i] << " ";
    cout << endl;
    // cout << endl;
    // //cout << arr[1];
    // int myarray[] = { 8, 5, 2, 6, 4};
    // sortArray(myarray, 5);
    // 
    // int array1[15] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
    // turnSideways(array1, 15);for(int i = 0; i < 5; i++)
    // {
    //     cout << myarray[i];
    // }
    // for(int i = 0; i < 15; i++) cout<< array1[i];
    // cout << fish_placer(2, "sideways", 81, ray, "Le'Tall");
    // for(int i = 0; i < 27; i++) cout<< ray[i] << " ";
    // cout << endl;
    // cout << fish_placer(6, "sideways", 81, ray, "six_tall");
    // for(int i = 0; i < 27; i++) cout<< ray[i] << " ";
    // cout << endl;
    //int y[6] = {15, 16, 18, 19, 21, 22};
    //turnSideways(y, 6, 81);
    //sortArray(y, 6);
    //for(int i = 0; i < 6; i++) cout<< y[i] << " ";
    //cout << Analyzer(ray, "fishy", 15);
}
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Fish.h"
using namespace std;

int main()
{
    Fish one("fishy", "goldfish", 'o');
    // cout << one.getHappiness() << endl;
    // cout << one.getHealth() << endl;
    // cout << one.getName() << endl;
    // cout << one.getPattern() << endl;
    // cout << one.getSpecies() << endl;
    // cout << one.getFed() << endl;
    // one.changeHealth(5);
    // cout << one.getHealth() << endl;
    // one.changeFed(2);
    // cout << one.getFed() << endl;
    // one.resetFed();
    // cout << one.getFed() << endl;
    // one.changeHappiness(-3);
    // cout << one.getHappiness() << endl;
    // one.changeHappiness(10);
    // cout << one.getHappiness() << endl;
    // cout << one.getSize() << endl;
    // cout << one.getOrientation() <<endl;
    one.printFoodType();
    cout << one.getFoodNumber() << endl;
    cout << one.matchFoodType("Meat") <<endl;
    cout <<one.matchFoodType("other") <<endl;
    
}
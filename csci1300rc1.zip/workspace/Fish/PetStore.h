#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Fish.h"
#include "Item.h"
#include "Tank.h"
using namespace std;
#ifndef PETSTORE_H
#define PETSTORE_H

class PetStore
{
   public:
    int buyTank(int money);
    int tankadder(int cost);
    int buyFish(int money);
    Fish fishadder(int cost, string name);
    int purchasePetItem(int money);
    int getItemcost(int number);
    Item getItem(int number);
    int sellfish(string species, char pattern);
};
#endif
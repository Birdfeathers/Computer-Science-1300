#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Fish.h"
using namespace std;

int Split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

Fish :: Fish(string Name, string Species, char Pattern)
{
   name = Name;
   species = Species;
   pattern = Pattern;
   happiness = 0;
   health = 0;
   fed = 0;
   string array1[5];
    string line;
    ifstream info;
    info.open("FishInfo.txt");
    while(getline(info, line))
    {
        Split(line, ';', array1, 5);
        if(array1[0]== species)
        {
            size = stoi(array1[1]);
            orientation = array1[2];
            foodnumber = stoi(array1[4]);
            Split(array1[3], ',',foodtype, 7);
        }
    }  
   
}

string Fish :: getName()
{
    return name;
}

string Fish :: getSpecies()
{
    return species;
}

char Fish :: getPattern()
{
    return pattern;
}
int Fish ::getHappiness()
{
    return happiness;
}

void Fish ::changeHappiness(int amount)
{
    happiness = happiness + amount;
    if(happiness > 10) happiness = 10;
    if(happiness < -10)happiness = -10;
}

 int Fish :: getHealth()
 {
     return health;
 }
 
 void Fish :: changeHealth(int amount)
 {
     health = health + amount;
     if(health > 10) health = 10;
 }
 
 int Fish :: getFed()
 {
     return fed;
 }
 
 void Fish :: changeFed(int amount)
 {
     fed = fed + amount;
 }
 void Fish ::resetFed()
 {
     fed = 0;
 }
 
int Fish :: getSize()
{
    return size;
}
string Fish :: getOrientation()
{
    return orientation;
}

void Fish :: printFoodType()
{
    cout << "This fish eats : ";
    for(int i = 0; i < 7; i++)
    {
        if(foodtype[i] != "NA")cout << foodtype[i] << ", ";
    }
    cout << endl;
}

bool Fish :: matchFoodType(string Foodtype)
{
    for(int i = 0; i < 7; i++)
    {
        if(foodtype[i] == Foodtype) return true;
    } 
    return false;
}


int Fish :: getFoodNumber()
{
    return foodnumber;
}

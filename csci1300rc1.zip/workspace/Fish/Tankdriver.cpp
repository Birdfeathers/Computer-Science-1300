#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Tank.h"
#include "Fish.h"
#include "Item.h"
using namespace std;
// to run : g++ -std=c++11 Fish.cpp Tank.cpp Tankdriver.cpp Item.cpp

int main()
{
    Tank tanky(81, "tanky");
    //tanky.displayTank();
//     Fish fishy("fishy", "goldfish", 'o');
//     Fish Munchy("Munchy", "MediumPacificKelpMuncher", 'p');
//     Fish Packy("Packy", "Pacu",'>' );
     Fish Takahashi("Takahashi", "Seahorse", 'j');
//     Fish Momal("Momal", "MediumPacificKelpMuncher", '{');
//     tanky.addFish(fishy);
//     tanky.addFish(Munchy);
//     tanky.addFish(Packy);
     tanky.addFish(Takahashi);
//     tanky.addFish(Momal);
//     //Tank fishbowl(1, "fishbowl");
//     //fishbowl.addFish(fishy);
//     //fishbowl.addFish(Munchy);
//     //fishbowl.addFish(fishy);
//     tanky.listTank();
//     //tanky.setWaterQuality(10);
//     //tanky.setCleanliness(-10);
//     //tanky.listTank();
//     //tanky.setWaterQuality(-7);
//     //tanky.setCleanliness(7);
//     //tanky.listTank();
//     //tanky.setWaterQuality(-8);
//     //tanky.setCleanliness(9);
//   // tanky.listTank();
//       tanky.listFish();
//     //cout << endl;
//     //fishbowl.listFish();
//     //tanky.removeFish(1);
//     //tanky.displayTank();
//     //tanky.listFish();
//     //tanky.moveFish();
//     tanky.resetTank();
//     tanky.resetTank();
//     tanky.resetTank();
//     tanky.resetTank();
//     tanky.resetTank();
//     tanky.resetTank();
//     tanky.listFish();
//     tanky.listTank();
    // Fish seagrass("seagrass", "SeaTurtle", 'M');
    // Fish Gallon("Gallon", "SeaTurtle",'?');
    // Fish yo("yo", "SeaTurtle", 'y');
    // tanky.addFish(seagrass);
    // tanky.addFish(Gallon);
    // tanky.addFish(yo);
    Fish Tiger("Tiger","TigerShark", '.');
    tanky.addFish(Tiger);
    Fish Nelly("Nelly","LakeMonster", '9');
    tanky.addFish(Nelly);
    Fish Box("Box", "BoxTurtle", 'B');
    Fish Bite("Bite", "Barracuda", 'L');
    tanky.addFish(Box);
    tanky.addFish(Bite);
    tanky.displayTank();
    tanky.listTank();
    tanky.listFish();
    
}
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Forest.h"
using namespace std;

void Forest :: ForestMenu()
{
	cout << "What would you like to do in the forest?" <<endl;
	cout << "1. Search forest" <<endl;
	cout << "2. Leave" <<endl;
}

string Forest:: searchForest()
{
	srand (time(NULL));
	int random = rand() % 100;
	if(random <10) return "nothing";
	if(random <35) return "forestGreens";
	if(random <43) return "veryBerry";
	if(random < 51) return "quince";
	if(random < 60) return "acorn";
	if(random < 70) return "stick";
	if(random < 80) return "rock";
	return "trash";
}
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#ifndef USER_H
#define USER_H

class User
{
    public:
        User();
        int getMoney();
        void setMoney(int newmoney);
        int getStamina();
        void setStamina(int newStamina);
        int getDrowsiness();
        void setDrowsiness(int newDrowsiness);
        
    private:
        int stamina;
        int drowsiness;
        int money;
};
 #endif
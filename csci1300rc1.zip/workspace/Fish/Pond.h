#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#ifndef POND_H
#define POND_H

class Pond
{
    public:
        void PondMenu();
        char randomchar();
        string returnSpecies();
        string fish();
        string item();
        string scavenged();
};

#endif
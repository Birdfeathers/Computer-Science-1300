#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include "Item.h"
#include "Fish.h"
#include <vector>
using namespace std;
#ifndef TANK_H
#define TANK_H

class Tank
{
    public:
        Tank(int Size, string name);
        int getCleanliness();
        void setCleanliness(int newclean);
        int getWaterQuality();
        void setWaterQuality(int newquality);
        string getTankName();
        //void setTankName(string name); - may not need this
        string getArrangementAt(int number); 
        void setArrangementAt(int number, string setting);
        void listTank();
        void listFish();
        void displayTank();
        bool addFish(Fish newfish);
        bool removeFish(int fishnumber);
        bool moveFish();
        void resetTank();
        bool feedFish(Item Item1);
        bool hasSameName(string testname);
        void loadFish(Fish Fish1);
        int getTankSize();
        int getNumFish();
        string getFishName(int fishnumber);
        string getFishSpecies(int fishnumber);
        char getFishPattern(int fishnumber);
        int getFishHappiness(int fishnumber);
        int getFishHealth(int fishnumber);
        int getFishFed(int fishnumber);
        Fish getFish(int fishnumber);
    private:
        vector <Fish>tankFish;
        int size;
        int cleanliness;
        int water_quality;
        string tankName;
        string arrangement[200];
};
#endif
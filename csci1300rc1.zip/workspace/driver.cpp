#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace std;

void display(CashRegister reg)
{
    cout << reg.getNumItems() << "$" << fixed << setprecision(2)
    << reg.getTotal() << endl;
}

int main()
{
    CashRegister reg1; // create an object 
    display(reg1);
    return 0;
}
//constructors
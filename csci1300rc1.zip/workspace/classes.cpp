#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

// object oriented programming/ oop
// don't use global variables
// new terminalogy data associated w/ object- sometimes called attributes
// encapsulation- all attributes of one object hidden from other parts of the function
// encapsulation make things more manageable
//class NameOfClass
//{
//public:
//public interface
//private:
// data members
//mutators and accessors 
// mutatirs modify data- don't return anything
// accessors return a value
}
int main()
{
    
}
#include <iostream>
#include <iomanip>

using namespace std;

string DayOfWeek(int day)
{
    switch (day)
    {
    case 1: return "MONDAY";
    case 2:
    case 3:
    case 4: return "WORKDAY";
    case 5: return "FUNDAY";
    case 6:
    case 0: return "SLEEPDAY";
    default: return "INVALID";
    }
}

int main()
{
    cout << DayOfWeek(3);
}
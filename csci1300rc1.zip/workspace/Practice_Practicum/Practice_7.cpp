#include <iostream>

using namespace std;

string shapeName(int numsurface)
{
    switch(numsurface)
    {
        case 2: return "CONE";
        case 3: return "CYLINDER";
        case 4: return "TRIANGULARPYRAMID";
        case 6: return "CUBOID";
        default: return "UNKNOWN";
    }
}
int main()
{
    cout << shapeName(-2) << endl;
    cout << shapeName(2) << endl;
}
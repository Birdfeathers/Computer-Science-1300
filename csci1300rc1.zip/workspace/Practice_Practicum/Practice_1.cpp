#include <iostream>

using namespace std; 

double CoffeeCost(int numcups, double pricecup)
{
    int freecups = numcups / 13;
    double price = (numcups-freecups) * pricecup;
    return price;
}

int main()
{
    cout << CoffeeCost(12, 3);
    cout << CoffeeCost(14, 3);
}
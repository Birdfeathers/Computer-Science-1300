#include <iostream>
#include <iomanip>

using namespace std;

void LeavesPerTree( double pounds)
{
    double numleaves =  pounds / 0.001;
    double leavespertree = numleaves / 1031;
    cout << leavespertree << endl;
    if( leavespertree > 10000)cout << "More leaves than last year";
}

int main()
{
    LeavesPerTree(100000);
}
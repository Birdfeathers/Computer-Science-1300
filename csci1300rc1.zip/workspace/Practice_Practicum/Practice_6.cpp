#include <iostream>
#include <iomanip>

using namespace std;

void calculator(double num1, double num2, char oper)
{
   double answer;
   
       switch(oper)
       {
           case '+': answer = num1 + num2;
           cout << num1 << " + "<< num2 << " = " << setprecision(2)<< answer <<endl;
           break;
           case '-': answer = num1 - num2;
           cout << num1 << " - "<< num2 << " = " <<setprecision(2)<<answer<< endl;
           break;
           case '*': answer = num1 * num2;
           cout << num1 << " * "<< num2 << " = " << setprecision(2) << answer <<endl;
           break;
           case '/': answer = num1 / num2; 
           cout << num1 << " / "<< num2 << " = " << setprecision(2) << answer<< endl;
           break;
           default: cout << "Invalid operator!";break;
       }
    
}

int main()
{
    calculator(3, -7, '+');
}
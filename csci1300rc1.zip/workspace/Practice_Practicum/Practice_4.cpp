#include <iostream>

using namespace std;

double PaintHouse(int width, int depth, int window)
{
    int perimeter = 2 * (width + depth);
    double window_cost = 6.75 * window;
    double cost;
    if( width < 0 || window < 0 || depth < 0) return -1;
    else if (perimeter < 100)
    {
      cost = perimeter * 8 ;
    }
    else if(perimeter < 200)
    {
        cost = 800 + (perimeter - 100) * 10;
    }
    else
    {
        cost = 1800 + (perimeter- 200)* 15;
    }
    cost = cost + window_cost;
    return cost;
    
}

int main()
{
    cout << PaintHouse(15, 25, 8);
}
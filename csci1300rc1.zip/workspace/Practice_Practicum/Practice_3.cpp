#include <iostream>

using namespace std;

string GolfName(int number)
{
    switch(number)
    {
        case -2: return "EAGLE";
        case -1: return "BIRDIE";
        case 0: return "PAR";
        case 1: return "BOGIE";
        case 2: return "DOUBLE BOGIE";
        case 3: return "TRIPLE BOGIE";
        default: return "NO COMMENT";
    }
}
int main()
{
    cout << GolfName(-2) << endl;
    cout << GolfName(2) << endl;
}
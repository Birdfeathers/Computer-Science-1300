#include <iostream>
#include <iomanip>

using namespace std;

double PizzaParty(int numpizzas, double costpizza, double discount)
{
    double cost;
    if(numpizzas < 10)
    {
        cost = (numpizzas * costpizza)+ 10;
    }
    else
    {
        cost = numpizzas * (costpizza - (discount* costpizza));
    }
    return cost;
}

int main()
{
    cout << PizzaParty(10 , 10, .1)<< endl;
    cout <<PizzaParty(5, 10, .2) << endl;
}
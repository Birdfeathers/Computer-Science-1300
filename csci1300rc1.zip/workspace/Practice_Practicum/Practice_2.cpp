#include <iostream>

using namespace std;

double GasBill(int gas)
{
    double cost;
    if (gas < 0)
    {
        cout << "Incorrect input" << endl;
        cost = 0;
    }
    else if(gas< 100)
    {
      cost = gas * 1.23; 
    }
    else if(gas < 200)
    {
        cost = (100 * 1.23) + (gas-100)*1.14;
    }
    else
    {
        cost = (100 * 1.23)+ (100 *1.14) + (gas-200)* 1.08;
    }
    return cost;
}

int main()
{
    cout << GasBill(244)<< endl;
    cout << GasBill(82)<<endl;
}
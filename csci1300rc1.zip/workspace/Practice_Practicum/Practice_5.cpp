#include <iostream>

using namespace std;

double TuitionCost(int units, double cost_unit)
{
    double cost;
    if (units < 0 || cost_unit < 0) return -1;
    if (units <= 16)
    {
      cost = units *cost_unit;  
    }
    else
    {
        cost= (16* cost_unit)+ (units-16)*(cost_unit/2);
    }
    return cost;
}

int main()
{
    cout << TuitionCost(16, 200) << endl;
    cout << TuitionCost(17, 300)<< endl;
}
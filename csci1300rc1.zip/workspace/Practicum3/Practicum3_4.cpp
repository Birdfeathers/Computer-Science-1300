#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int matrixThreshold(int dray[][2], int size, int threshold)
{
    int number = 0;
    for(int i = 0; i < size; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            if(dray[i][j] >= threshold)number++;
        }
    }
    return number;
}





int main()
{
    int array[1][2]={{13,15}};
    cout << matrixThreshold(array, 1, 14) << endl;
    int array1[2][2]={{1,1},{3,4}}; 

    cout << matrixThreshold(array1,2,3);
}
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;




void printCountriesOutOfRange(string country_names[], int medal_couts[],int size)
{
    for(int i = 0; i < size; i++)
    {
        if(medal_couts[i] < 10 || medal_couts[i] > 15)
        {
            cout << country_names[i] << " " << medal_couts[i]<<endl;
        }
    }
}



int main()
{
    string country[] = {"USA", "Mexico", "Norway", "Canada"};
    int medal[]= { 14, 3, 10, 12};
    printCountriesOutOfRange(country, medal, 4);
}
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

int calcPay(string file_name)
{
    ifstream file;
    file.open(file_name);
    if(!file.is_open())return -1;
    string line;
    int counter = 0;
    double Total =0;
    while(getline(file, line))
    {
        string array1[3];
        if (split(line, ',', array1, 3) == 3)
        {
             counter++;
             double total_pay = stoi(array1[1]) * stod(array1[2]);
            cout << array1[0] << ": " << total_pay << endl;
            Total = Total + total_pay;
        }
    }
    cout << "Total: " << Total <<endl;
    return counter;
}





int main()
{
    cout << calcPay("text.txt");
}
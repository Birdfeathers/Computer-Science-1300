#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int sumOfPositiveOdd(string file_name, int arr[], int size)
{
    int sum =0;
    for(int i = 0; i < size; i++)
    {
        if(arr[i] > 0 && arr[i]%2 != 0)
        {
            sum = sum + arr[i];
        }
        ofstream outfile;
        outfile.open(file_name);
        if(!outfile.is_open())return -1;
        outfile << sum;
    }
    return 1;
}






int main()
{
    int arr[] ={1,2,3,4,5};
    cout << sumOfPositiveOdd("new.txt", arr, 5);
}
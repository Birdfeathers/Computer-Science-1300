#include <iostream>
using namespace std;

int main()
{
    double a = (100 +1.0/3)-100;
    int b= 1.0/3;
    if( a== b) cout<< "yes";
    else cout << "no";
}
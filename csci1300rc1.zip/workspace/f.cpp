#include <iostream>
#include <string>
using namespace std;


bool isAllAlpha(string x)
{
   int counter = 0;
   int length=  x.length();
   for(int i= 0; i< length; i++) 
   {
       if((x[i] >= 'A' && x[i] <= 'Z')||(x[i] >= 'a'&& x[i] <= 'z'))
       {
           counter++;
       }
   }
    if(counter == x.length()) return true;
       else return false;
}


int main()
{
   cout<< isAllAlpha("ABC"); 
   cout<< isAllAlpha("A4kk");
}

#include <iostream>

using namespace std;

int userturn()
{
   char yesno;
    cout <<"It is now human's turn."<< endl << endl<< "Do you want to roll a dice (Y/N)?:";
    cin >> yesno;
    cout << yesno;
    
}

int main()
{
    userturn();
}
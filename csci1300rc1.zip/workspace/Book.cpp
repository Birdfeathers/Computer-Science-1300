#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Book.h"
using namespace std;

Book :: Book()
{
    title = "";
    author = "";
}

Book :: Book(string t,string a)
{
    title = a;
    author = t;
}

string Book :: getTitle()
{
    return title;
}

void Book :: setTitle(string booktitle)
{
    title = booktitle;
}
string Book :: getAuthor()
{
    return author;
}
void Book :: setAuthor(string bookauthor)
{
    author = bookauthor;
}
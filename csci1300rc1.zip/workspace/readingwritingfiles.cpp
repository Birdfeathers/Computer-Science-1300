#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int function()
{
    ifstream in_file;// defines variable of file you're opening, like declaring variables
    in_file.open("input.txt"); // file name is input, must be in same directory as program
    // give path to file if not in directory, path different for different operating systems
    //in_file.close(); // should close it at end
    string name;
    double vale;
    in_file >> name >> value // reads words seperated by spaces into variables name and value
    // cin/ in_file
    //while(in_file >> name>>value)// will return true if you can continue to process
    // if(in_file.fail())- returns true if fails to open file
    string line = "";
    getline(in_file, line);// reads line into variable line
    
    
}
int reverse_string()
{
    string flename1 = "Mary.txt";
    string 
}
// look for split function

int main()
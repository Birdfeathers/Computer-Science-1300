// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 6 - Problem # 1

#include <iostream>
using namespace std;

int main()
{
    int arrayOne[49];
    float arrayTwo[4];
    bool arrayTri[14];
    string arrayFor[12];
}
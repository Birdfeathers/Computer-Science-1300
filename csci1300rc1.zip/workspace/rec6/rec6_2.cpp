// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 6 - Problem # 2

#include <iostream>
#include <string>
using namespace std;

int main()
{
  float temps[10]= {-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67};
  string colors[5]= {"Red", "Blue", "Green", "Cyan", "Magenta"};
  int sequence[100]; 
  for (int i = 0; i < 100; i++)
   {
      sequence[i] = i + 1;
   }
}
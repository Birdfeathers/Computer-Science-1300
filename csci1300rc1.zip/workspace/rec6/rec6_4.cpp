// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 6 - Problem # 4

#include <iostream>
#include <string>
using namespace std;

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int numentry = 1;
    for(int i =0; i < splitlength; i++)
    {
        if(split[i] == del)numentry++;
    }
    
    if(numentry > length)
    {
        int wordlength=0;
        int entry=0;
        for(int i = 0; entry < length; i++)
        {
            
            if(split[i] == del || i == splitlength)
            {
                arr[entry]= split.substr(i-wordlength, wordlength);
                wordlength = -1;
                entry++;
            }
            wordlength++ ;
        }
        return -1;
    }
    else
    {
        int wordlength=0;
        int entry=0;
        for(int i = 0 ; i <= splitlength; i++)
        {
            if(split[i] == del || i == splitlength)
            {
                arr[entry]= split.substr(i-wordlength, wordlength);
                if(arr[entry] == "") 
                {
                    entry--;
                }
                wordlength = -1;
                entry++;
            }
            wordlength++ ;
        }
        return entry;
    }
}


int getScores(string scores, int store[], int length)
{
    string bar[length];
    int numscores= split(scores, ' ', bar, length);
    for(int i = 0; i < length; i++)
    {
        int score;
        if(i < numscores) score = stoi(bar[i]);
        if(numscores == -1 && bar[i] != "") score = stoi(bar[i]);
        store[i] = score;
    }
    
    return numscores;
}

int main()
{
    int nums[6];
    // cout<< getScores("15 2007 5",nums,6)<<endl;
    // cout<<nums[0]<<endl<<nums[1];
    // cout<<getScores("123 456 789 000",nums,6);
    // cout<<nums[0]<<endl<<nums[1];
    // cout<< getScores("", nums, 6);
    // cout <<getScores(" 123 ", nums, 6); 
    // cout<<nums[0]<<endl<<nums[1];
    cout<< getScores("15 2007 5",nums,2);
    cout<<nums[0]<<endl<<nums[1];

}
#include <iostream>
#include <string>
using namespace std;

int getWordNumber(string phrase, char del)
{
    int phraselength = phrase.length();
    int wordnumber = 0;
    for(int i=0; i < phraselength; i++ )
     {
       if(phrase[i] != del)
         {
            while(phrase[i] != del&& i < phraselength)i++;
            wordnumber++;
         }
     }
    return wordnumber;
}


int split(string split, char del,string arr[] , int length)
{
    int numentry = getWordNumber(split, del);
    int splitlength = split.length();
    int max, return_value;
    if (numentry > length)
    {
      max = length;
      return_value = -1;
    }
    else
    {
        max = numentry;
        return_value = numentry;
    }
    
    int wordlength=0, entry =0;
    for(int i = 0 ; entry < max; i++)
        {
            if(split[i] == del || i == splitlength)
            {
                arr[entry]= split.substr(i-wordlength, wordlength);
                 if(arr[entry] == "") 
                {
                    entry--;
                }
                wordlength = -1;
                entry++;
            }
            wordlength++ ;
        }
        return return_value;
}

int getScores(string scores, int store[], int length)
{
    string bar[length];
    int numscores= split(scores, ' ', bar, length);
    for(int i = 0; i < length; i++)
    {
        int score;
        if(i < numscores) score = stoi(bar[i]);
        if(numscores == -1 && bar[i] != "") score = stoi(bar[i]);
        store[i] = score;
    }
    
    return numscores;
}



int main()
{
   // cout<<getWordNumber("  the only one", ' ')<<endl<< getWordNumber(" ", ' ');
//   string words[6];
//   cout<< split("unintentionally",'n',words,6);
//   cout << split("   r   r", ' ', words, 6);
int nums[6];
   cout<< getScores("15 2007    ",nums,2);
   cout<<endl<< nums[0]<<endl<<nums[1];
}
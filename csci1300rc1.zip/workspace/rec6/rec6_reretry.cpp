#include <iostream>
#include <string>
using namespace std;

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

int getScores(string scores, int store[], int length)
{
    string bar[length];
    int numscores= split(scores, ' ', bar, length);
    for(int i = 0; i < length; i++)
    {
        int score;
        if(i < numscores) score = stoi(bar[i]);
        if(numscores == -1 && bar[i] != "") score = stoi(bar[i]);
        store[i] = score;
    }
    
    return numscores;
}



int main()
{
   // cout<<getWordNumber("  the only one", ' ')<<endl<< getWordNumber(" ", ' ');
   //string words[6];
//   cout<< split("unintentionally",'n',words,6);
//   cout << words[0]<< words[1];
  // cout << split("   r   r", ' ', words, 6);
   //cout << split("", ' ', words,6 );
   int nums[6];
   cout<< getScores("15 2007    ",nums,1);
   cout<<endl<< nums[0]<<endl<<nums[1];
   
   
}
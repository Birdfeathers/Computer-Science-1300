// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 6 - Problem # 3

#include <iostream>
#include <string>
using namespace std;

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    //if(splitlength == 0)return 0; 
    int numentry = 1;
    for(int i =0; i < splitlength; i++)
    {
        if(split[i] == del)numentry++;
    }
    
    if(numentry > length)
    {
        int wordlength=0;
        int entry=0;
        for(int i = 0 ; entry < length; i++)
        {
            if(split[i] == del || i == splitlength)
            {
                arr[entry]= split.substr(i-wordlength, wordlength);
                wordlength = -1;
                entry++;
            }
            wordlength++ ;
        }
        return -1;
    }
    else
    {
        int wordlength=0;
        int entry=0;
        for(int i = 0 ; i <= splitlength; i++)
        {
            if(split[i] == del || i == splitlength)
            {
                arr[entry]= split.substr(i-wordlength, wordlength);
                if(arr[entry] == "") 
                {
                    entry--;
                }
                wordlength = -1;
                entry++;
            }
            wordlength++ ;
        }
        return entry;
    }
}


int main()
{
    
    string words[6];
    // cout << split("one small step", ' ', words, 6);
    // cout<< words[0]<< words[1] << words[2] << words[3];
    // cout<< split("one small step",' ',words, 2); 
    cout << split("", ' ', words, 6);
    cout << split("   ", ' ', words, 6);
    cout<< words[0];
    
    
    cout<< split("unintentionally",'n',words,6); 
    
}
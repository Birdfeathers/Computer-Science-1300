#include <iostream>
#include <string>
using namespace std;

string substring(string large)
{
  int i = 0;
  int sub
  string mySubstring = large.substr
}

int main()
{
    
}
#include <iostream>
using namespace std;

int main() {
    int seconds;
    cin >> seconds;
    int days = seconds / 86400;
    int hours = (seconds - (86400 * days)) / 3600;
    int minutes = (seconds- (86400 * days)- (3600 * hours))/ 60;
    seconds = seconds - (86400 * days) - (3600 * hours) - (60 * minutes);
    cout << "The time is " << days << " days " << hours << " hours, " << minutes << " minutes, and " << seconds << " seconds" <<endl;
}
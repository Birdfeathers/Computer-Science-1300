#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

// type/class
// let's do cash register w/o classes first - a bunch of variables
// changing value of two variables- need two functions
// with classes

class CashRegister
{
    public:
        void clear();
        void addItem(double price); // modifies total, so doesn't need to return anything
        double getTotal();
        int getNumItems();
        // usually every variable gets 2 functions
    private:
        double total;
        int numItems;
}

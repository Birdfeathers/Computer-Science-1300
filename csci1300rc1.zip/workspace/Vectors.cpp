#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;
//not fixed size when created
// does not have an auxilary variable
// can keep putting things into it
//vector<double> data; //data is empty
//vector<double> data(10); //decalres inital size
//data[i] // acess element
//data.size() //will return the size
//values.push_back(32); vector size increases by one
//values.pop_back();//removes last element
//passed by reference & - passed by reference
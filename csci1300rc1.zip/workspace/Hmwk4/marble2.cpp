#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

int rollDice(int legal)
{
	return random() % legal + 1; 
}

int stupid(int marbles)
{
    int legal = marbles/2;
    return rollDice(legal);
}

int smart(int marbles)
{
    int nearest = log(marbles)/log(2);
    int power = pow(2, nearest)- 1;
    int last =pow(2, (nearest+1))-1;
    if(marbles == last) return stupid(marbles);
    else return(marbles - power);
}

int Human_move(int marbles)
{
    int user_response = 0;
    int legal = marbles/2;
    while(user_response > legal || user_response < 1)
    {
    cout <<"Your move. Marbles remaining: " << marbles<< endl;
    cin >> user_response;
    if (user_response > legal || user_response < 1)
        {
        cout << "Wrong Move. You can only choose between 1 to " << legal <<endl;

        }
    
    }
     return marbles - user_response;
    
}

int Computer_move(int marbles, bool compmode)
{
    cout << "Computer is playing.." << endl;
    int taken;
    if(compmode == 0) taken = stupid(marbles);
    else taken = smart(marbles);
    cout << "Computer took "<<taken<<endl;
    return marbles - taken;
}

void marbleRun(int marbles, bool compmode, bool turn)
{
    string first_player;
    if(turn == 1) first_player = " Computer";
    else first_player = " Human";
    cout<< "Lets start the game!" << endl; 
    cout<< "Initial size is: "<< marbles <<endl<< "First player to play:" << first_player<<endl;
    string answer;
    if (compmode == 0) answer = " No";
    else answer = " Yes";
    cout << "Is computer in smart mode?"<<answer<<endl;
    while(marbles > 1)
    {
        if(turn == 1)
        {
            marbles = Computer_move(marbles, compmode);
            turn = 0;
        }
        else
        {
            marbles = Human_move(marbles);
            turn = 1;
        }
        cout << "Remaining marbles: "<< marbles<< endl;;
    }
    if(turn == 1) cout <<"You Win. Computer loses";
    else cout << "You lose. Computer won";
    
}

int main()
{

    marbleRun(200,1,0);
    
}
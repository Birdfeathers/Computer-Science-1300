int rollDice(int legal)
{
	return random() % legal + 1; 
}

int stupid(int marbles)
{
    if(marbles==1) return 1;
    int legal = marbles/2;
    return rollDice(legal);
}

int smart(int marbles)
{
    if(marbles==3 || marbles == 7 || marbles==15 || marbles == 31 || marbles == 63)
    {
        return stupid(marbles);
    }
    else if(marbles > 63) return marbles-63;
    else if(marbles > 31) return marbles-31;
    else if (marbles > 15)return marbles-15;
    else if (marbles > 7)return marbles-7;
    else if (marbles > 3)return marbles-3;
    else return 1;
}

int Human_move(int marbles)
{
    int user_response = 0;
    int legal;
    if(marbles == 1) legal = 1;
    else legal = marbles/2;
    if(marbles == 1) return 0;
    cout <<"Your move. Marbles remaining: " << marbles<< endl;
    cin >> user_response;
    if(user_response != 1)
    {while (user_response > legal || user_response < 1)
        if ((user_response > legal || user_response < 1) && user_response !=1 )
        {
        cout << "Wrong Move. You can only choose between 1 to " << legal <<endl;
        cout <<"Your move. Marbles remaining : " << marbles<< endl;
        cin >> user_response;
        }
    
    }
     return marbles - user_response;
    
}

int Computer_move(int marbles, bool compmode)
{
    cout << "Computer is playing.." << endl;
    int taken;
    if(compmode == 0) taken = stupid(marbles);
    else taken = smart(marbles);
    cout << "Computer took "<<taken<<endl;
    return marbles - taken;
}

void marbleRun(int marbles, bool compmode, bool turn)
{
    string first_player;
    if(turn == 1) first_player = " Computer";
    else first_player = " Human";
    cout<< "Lets start the game!" << endl; 
    cout<< "Initial size is: "<< marbles <<endl<< "First player to play:" << first_player<<endl;
    string answer;
    if (compmode == 0) answer = " No";
    else answer = " Yes";
    cout << "Is computer in smart mode?"<<answer<<endl;
    while(marbles > 1)
    {
        if(turn == 0)
        {
            marbles = Computer_move(marbles, compmode);
            turn = 1;
        }
        else
        {
            marbles = Human_move(marbles);
            turn = 0;
        }
        cout << "Remaining marbles: "<< marbles<< endl;;
    }
    if(turn == 0) cout <<"You Win. Computer loses";
    else cout << "You lose. Computer won";
    
}
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

int rollDice()
{
	return random() % 6 + 1; 
}



int user_turn()
{
    cout << "It is now human's turn" <<endl << endl;
    int turnTotal = 0;
    char user_response;
    bool turnEnd = 0;
    while (turnEnd == 0)
    {
        cout << "Do you want to roll a dice (Y/N)?:";
        cin >> user_response;
        if (user_response == 'y' || user_response == 'Y')
        {
          int diceRoll = rollDice();
          if (diceRoll == 2 || diceRoll == 4 || diceRoll == 5)
          {
              turnTotal = turnTotal + diceRoll;
          }
          if (diceRoll == 1 || diceRoll == 6)
          {
              turnTotal = 0;
              turnEnd = 1;
          }
          if (diceRoll == 3)
          {
              turnTotal = 15;
              turnEnd = 1;
          }
          cout << "You rolled a " << diceRoll <<endl << "Your turn total is " << turnTotal <<endl;
        }
        else
        {
            turnEnd = 1;
        }
    }
     return turnTotal;
}





int main()
{
    int userTurnTotal = user_turn();
    cout << userTurnTotal;
}

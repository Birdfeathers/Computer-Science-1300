// CSCI1300 Fall 2018
// Author: Rebecca Carr
// Recitation: 108 - Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Project1 







///////////////////////////////////////////////////////////////////////////////////////////////////
// Step1: Steps to solve this problem
// write an algorithm in pseudocode explaining on how you are approaching the problem, step by step 
///////////////////////////////////////////////////////////////////////////////////////////////////

/* Algorithm: Play Jepardy Dice
I broke this problem up into the game function, which:
	-provides an alternating turn order 
	-keeps track of the human’s and computer’s score 
	-relays it after each turn, and prints the opening and closing text
The turn function, which:
	-the game function calls to play a turn.
	-Keeps track of the score for that turn
The round function, which:
	-The turn function calls to handle one round within a turn of rolling dice or choosing not to.
	-Reports back the round total.
And the print text function which:
	-The turn function calls to print text with what the player rolled and their turn total at the end of each round. 
Here’s a more detailed description of how each function works:
 In Function game():
	1. Print "Welcome to Jeopardy Dice!" as text at to initiate the game.
	2. Create variables to keep track of the human’s total and computer’s total score in the game and initially set them as zero. 
	3. So the computer can tell whose turn it is, create a boolean variable in which 0 represents the human’s turn and 1 represents the computer’s turn. Initially set it to zero because the human goes first.
	4.Create a while loop which will continue the game until either the human or computer reaches 100 points at which point it will be the end of the game. Within this loop:
		a. Create an if statement for when it’s the human’s turn, indicated by the turn variable being zero. Within this statement: 
			i. Print, “It is now human’s turn.”
			ii. Call the turn function with the parameter “human” so it will play human’s turn and return the total turn score, add this score to human’s total score.
			iii.Switch the turn variable to “1” for computer’s turn. 
		b. Create an if statement for when it’s the computer’s turn, indicated by the turn variable being one. Within this statement:
			i. Print, “It is now computer’s turn.”
			ii. Call the turn function with the parameter “computer” so it will play computer’s turn and return the total turn score, add this score to computer’s  total score.
			iii. Switch the turn variable to “0” for human’s turn. 
		c. Print the total for the human and the computer after each turn
	5. Once a score reaches one hundred it will exit the loop, next:
		a. If computer reached 100 print, “Congratulations! computer won this round of jeopardy dice!"
		b. If human reached 100 print, "Congratulations! human won this round of jeopardy dice!"
In function turn:
	1. Receive the parameter of whether the player is human or computer.
	2. Create variables which keep track of round totals and turn totals, set them both to zero. 
	3. Create a while loop that continues calling the round function until the turn is over. When the round function is called it will 
	return a number which I set equal to the round total variable. I used negative numbers as code for an action/ dice roll that will end 
	a turn. The while loop will continue until round total is negative. Each round it will also:
		a. Add the round total to the turn total
		b. Unless the round total is zero, call the print function to tell the user info about that round.
	4. Once the loop is exited the turn is done. Convert the negative number into a turn total result:
		a. If it is a negative 1 or negative 4, this means a 1 or six was rolled so set turn total equal to zero
		b. If it is a negative 2, this means a three was rolled, so set turntotal equal to zero. 
		c. If it is a negative 3 this means the turn was manually exited, so add three to the turntotal to make up for the three that was taken away in step 3 a. 
	5.Call the print function one last time with the corrected turn total, as well parameters for player and roundtotal. 
	6. Return the turn total to the game function. 

In function round:
	1.Accept the parameters of the player and turn total so far.
	2. If the player is human, ask the user if they want to continue rolling by:
		a. Printing, “"Do you want to roll a dice (Y/N)?:" if their turn total is zero, indicating they haven’t rolled yet and
		b.Printing, “ "Do you want to roll again (Y/N)?:" if their turn total is not zero, indicating they rolled before.
		c. Accept user input into a new variable. If they respond ‘n’ or ‘N’ this indicates they want to end the turn, so return -3 to turn function. 
	3. If the player is computer, return the code -3 if the computer has a turn total equal to or greater than 10, because the computer should stop its turn after reaching that number. 
	4. Otherwise, use the dice roll function and put its value into a new variable.
	5. If the value of the diceroll is 2, 4, or 5 return the value of the dice roll to the turn function. Since these numbers are positive the turn will continue. If the value is 1, 6, or 3, return -4, -1 and -2 respectively. These will end the turn.

In function print text:
	1. Receive the turn total and round total from the turn function. 
	2. Convert the value of the round total round total it received back into its respective dice roll, i.e. -4 = 1, -1 =6, and -2 =3
	3.If the player is human, print the text: :
		“You rolled a (dice total)”
		“Your turn total is (turn total)”
	4.If the player is computer, print the text: :
		“Computer rolled a (dice total)”
		“Computer turn total is (turn total)”
	5. This function will also be accessed when the code was exited manually, round total = -3. To prevent it from printing these statements when no dice was rolled, only print these statements when round total is positive. 
 
*/




///////////////////////////////////////////////////////////////////////////////////////////////////
// Step2: Code it up! 
// After finishing up your pseudocode, translate them into c++ 
// IMPORTANT: rollDice() and main() are already written for you.
// You need to complete game function as well as at least 3 other additional functions
///////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

/**
 * rollDice 
 * returns a random integer between 1 and 6, works as rolling a dice.
 * return value, int number (1-6)
 */

int rollDice()
{
	return random() % 6 + 1; 
}

// your 3 + functions go in here
void print_text(string player, int diceRoll, int turntotal)
{
  if (diceRoll == -4) diceRoll =1;// converts turn vales back into dice rolls
  if (diceRoll == -1) diceRoll =6;
  if (diceRoll == -2) diceRoll =3;
  if(player == "human" && diceRoll > 0)// make sure it's above zero so this is skipped when turn value is -3
  {
     cout << "You rolled a "<< diceRoll<< endl << "Your turn total is "<< turntotal <<endl;  
  }
  if(player == "computer" && diceRoll > 0)
  {
     cout << "Computer rolled a " << diceRoll << endl <<"Computer turn total is "<<turntotal <<endl;
  }
}

int round(string player, int turntotal)
{
   if(player == "human")
   {
      if(turntotal == 0)//if it's zero they haven't gone yet
       {
           cout << "Do you want to roll a dice (Y/N)?:" << endl;
       }
       else
       {
           cout << "Do you want to roll again (Y/N)?:" << endl;
       }
       char user_response;
       cin >> user_response;
       if(user_response == 'N' || user_response =='n') return -3;//neg numbers will tell the turn loop to end
   }
   if (player == "computer" && turntotal >= 10) return -3;
   int Diceroll = rollDice();
   int return_value;
   switch (Diceroll)
   {
       case 2: return_value = 2; break;
       case 4: return_value = 4; break;
       case 5: return_value = 5; break;// the positive numbers will simply add to the turn total
       case 1: return_value = -4; break;
       case 6: return_value = -1; break;
       case 3: return_value = -2; break;// negative numbers will exit the turn
   }
   return return_value;
   
}

int turn(string player)
{
    int roundtotal = 0;
    int turntotal = 0;
    while (roundtotal >= 0) // when it's negative, that indicates a roll or the user ended the turn
    {
        roundtotal = round(player, turntotal);
        turntotal = turntotal + roundtotal;
        if (roundtotal > 0) print_text(player, roundtotal, turntotal);
    }
    if (roundtotal == -1 || roundtotal == -4) turntotal = 0;//convert exit codes into there effect
    if (roundtotal == -2)  turntotal = 15;
    if (roundtotal == -3) turntotal = turntotal + 3;// add the three subtracted in the loop
    print_text(player, roundtotal, turntotal);
    return turntotal;//gives total for this turn back to the game function
}

/**
 * game 
 * driver function to play the game
 * the function does not return any value
 */

void game()
{

cout << "Welcome to Jeopardy Dice!" << endl << endl;
    int human_total = 0;
    int computer_total = 0;
    bool whose_turn = 0; // if value is zero, humans turn, value one computer's turn
    while (human_total < 100 && computer_total < 100) // continues turns until game is won
    {
        if(whose_turn == 0)
        {
            cout << "It is now human's turn" <<endl << endl;
            human_total= human_total + turn("human"); // the turn function will return the total for this turn
            whose_turn = 1;// after human change back to computer's turn
        }
        else
        {
            cout << "It is now computer's turn"<<endl <<endl;
            computer_total= computer_total + turn("computer");
            whose_turn = 0;
        }
        
    cout << "computer: " << computer_total << endl <<"human: "<<human_total << endl <<endl;
    }
    if(computer_total >= 100)
    {
        cout << "Congratulations! computer won this round of jeopardy dice!";
    }
    if(human_total >= 100)
    {
        cout << "Congratulations! human won this round of jeopardy dice!";

    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// don't change the main. 
// Once you finished please paste your code above this line 
///////////////////////////////////////////////////////////////////////////////////////////////////


int main()
{
	// start the game! 
	game();
	return 0;
}
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

int rollDice()
{
	return random() % 6 + 1; 
}

void print_text(string player, int diceRoll, int turntotal)
{
  if (diceRoll == -4) diceRoll =1;
  if (diceRoll == -1) diceRoll =6;
  if (diceRoll == -2) diceRoll =3;
  if(player == "human" && diceRoll != -3)
  {
     cout << "You rolled a "<< diceRoll<< endl << "Your turn total is "<< turntotal <<endl;  
  }
  if(player == "computer" && diceRoll != -3)
  {
     cout << "Computer rolled a " << diceRoll << endl <<"Computer's turn total is "<<turntotal <<endl;
  }
}

int round(string player, int turntotal)
{
   if(player == "human")
   {
       cout << "Do you want to roll a dice (Y/N)?:";
       char user_response;
       cin >> user_response;
       if(user_response == 'N' || user_response =='n') return -3;
   }
   if (player == "computer" && turntotal > 10) return -3;
   int Diceroll = rollDice();
   int return_value;
   switch (Diceroll)
   {
       case 2: return_value = 2; break;
       case 4: return_value = 4; break;
       case 5: return_value = 5; break;
       case 1:
       case 6: return_value = -1; break;
       case 3: return_value = -2; break;
   }
   return return_value;
   
}

int turn(string player)
{
    int roundtotal = 0;
    int turntotal = 0;
    while (roundtotal >= 0)
    {
        roundtotal = round(player, turntotal);
        turntotal = turntotal + roundtotal;
        print_text(player, roundtotal, turntotal);
    }
    if (roundtotal == -1 ) turntotal = 0;
    if (roundtotal == -2)  turntotal = 15;
    if (roundtotal == -3) turntotal = turntotal + 3;
    return turntotal;
}


int main()
{
    cout << turn("computer");
}
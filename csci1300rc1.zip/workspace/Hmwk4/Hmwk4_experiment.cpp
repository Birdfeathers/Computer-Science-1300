#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

int rollDice()
{
	return random() % 6 + 1; 
}



int round(string player, int turntotal)
{
   if(player == "human" &&  turntotal >= 9) return -3;
   if (player == "computer" && turntotal >= 12) return -3;
   int Diceroll = rollDice();
   int return_value;
   switch (Diceroll)
   {
       case 2: return_value = 2; break;
       case 4: return_value = 4; break;
       case 5: return_value = 5; break;
       case 1: return_value = -4; break;
       case 6: return_value = -1; break;
       case 3: return_value = -2; break;
   }
   return return_value;
   
}

int turn(string player)
{
    int roundtotal = 0;
    int turntotal = 0;
    while (roundtotal >= 0)
    {
        roundtotal = round(player, turntotal);
        turntotal = turntotal + roundtotal;
    }
    if (roundtotal == -1 || roundtotal == -4) turntotal = 0;
    if (roundtotal == -2)  turntotal = 15;
    if (roundtotal == -3) turntotal = turntotal + 3;
    return turntotal;
}

string game()
{
    int human_total = 0;
    int computer_total = 0;
    bool whose_turn = 1;
    int randomnum = rollDice();
    if(randomnum > 3) whose_turn =0; 
    while (human_total < 100 && computer_total < 100)
    {
        if(whose_turn == 0)
        {
            human_total= human_total + turn("human");
            whose_turn = 1;
        }
        else
        {
            computer_total= computer_total + turn("computer");
            whose_turn = 0;
        }
        
    }
    if(computer_total >= 100)
    {
        return "computer";
    }
    if(human_total >= 100)
    {
        return "human";

    }
    
}
 
void diceExperiment()
{
    int counter = 0;
    int human_count = 0;
    int computer_count = 0;
    while (counter < 1000000)
    {
        string winner = game();
        if(winner == "human")
        {
            human_count++;
            counter++;
        }
        if(winner == "computer")
        {
            computer_count++;
            counter++;
        }
    }
    cout << "Human won "<< human_count<<" games, computer won "<< computer_count << " games."<< endl;
   
}

int whose()
{
    bool whose_turn = 0;
    int randomnum = rollDice();
    if(randomnum > 3) whose_turn =1;
    return whose_turn;
}

int randomness()
{
    int counter = 0;
    int human_count = 0;
    int computer_count = 0;
    while (counter < 1000000)
    {
        bool winner = whose();
        if(winner == 0)
        {
            human_count++;
            counter++;
        }
        if(winner == 1)
        {
            computer_count++;
            counter++;
        }
    }
    cout << "Human won "<< human_count<<" games, computer won "<< computer_count << " games."<< endl;
    
}

int main()
{
    diceExperiment();
}
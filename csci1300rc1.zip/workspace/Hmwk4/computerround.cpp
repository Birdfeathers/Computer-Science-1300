#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

int rollDice()
{
	return random() % 6 + 1; 
}


int computer_round()
{       if (turnTotal < 10)
        {
          int diceRoll = rollDice();
          if (diceRoll == 2 || diceRoll == 4 || diceRoll == 5)
          {
              turnTotal = turnTotal + diceRoll;
          }
          if (diceRoll == 1 || diceRoll == 6)
          {
              turnTotal = 0;
              turnEnd = 1;
          }
          if (diceRoll == 3)
          {
              turnTotal = 15;
              turnEnd = 1;
          }
        }
        else
        {
            turnEnd = 1;
        }
    }
     return diceRoll, turnTotal;
}

void print_values(string player, int diceRoll, int turnTotal)// try to get this to call the calclater
{
  cout << "It is now "<<player<< "'s turn" <<endl << endl; 
  int turnTotal = 0;
  bool turnEnd = 0;
  while (turnEnd == 0)
  {
     computer_round(); 
  }
  
  cout <<Player << " rolled a " << diceRoll <<endl <<Player <<"'s turn total is " << turnTotal <<endl;
  
}





int main()
{
    print_values
}
#include <iostream>
#include <string>
using namespace std;

int array()
{
    //const int CAPACITY= 100;
    double values[5]= { 32.0, 104.5, 1.0, 2.0, 3.0};
    cout << values[4]<<endl;
    return 0;
}

int main()
{
    array;
}
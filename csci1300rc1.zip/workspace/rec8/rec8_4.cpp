// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 8 - Problem # 4

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

void saveData(string file_name, string arr[], int n, int size)
{
    ofstream file;
    file.open(file_name);
    if(!file.is_open()) cout << "file open failed";
    else if(n < 0 || size < 0 );
    else
    {
        string name = arr[n];
        double total = 0;
        for(int i = 0; i < n; i++)
        {
            string arr_number = "";
            arr_number = arr_number + arr[i];
            double arr_int = stof(arr_number);
            total = total + arr_int;
        }
        
        if( n== 0) file << "Name: first value from array";
        else
        {
            double average = total / n;
            file << "Name: " << name << endl;
            file << "Avg: " << average << endl;
        }
    }
}

int main()
{
    string data[4] = {"2.3", "-1.5", "0.8", "Garth"};
    saveData("my_data.txt", data, 3, 4);
}
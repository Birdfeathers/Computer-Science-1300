// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 8 - Problem # 3

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

int fileLoadRead(string file_name)
{
    ifstream file;
    file.open(file_name);
    if(!file.is_open()) return-1;
    string line = "";
    int linenumber= 0;
    while(getline(file, line)) linenumber++;
    return linenumber;
}

int main()
{
    cout <<fileLoadRead("squares.txt") << endl;
    cout << fileLoadRead("h.txt") << endl;
}
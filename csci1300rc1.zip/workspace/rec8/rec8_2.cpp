// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 8 - Problem # 2

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

int fileLoadWrite(string file_name)
{
    ofstream file;
    file.open(file_name);
    if(!file.is_open()) return-1;
    for(int i = 1; i <= 10; i++)
    {
        file << i * i << endl;
    }
    return 0;
}

int main()
{
    cout<<fileLoadWrite("squares.txt");
}
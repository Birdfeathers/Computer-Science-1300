// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 8 - Problem # 1

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

bool checkFile(string file_name)
{
    bool truthvalue = 0;
    ifstream file;
    file.open(file_name);
    if(file.is_open()) truthvalue =1;
    return truthvalue;
}

int main()
{
    cout << checkFile("h.txt");
}
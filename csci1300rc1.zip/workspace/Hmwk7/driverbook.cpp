#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Book.h"
using namespace std;

int main()
{
    Book one;
    cout<< "one" << one.getAuthor() << "two" << endl;
    cout<< "one" << one.getTitle() << "two" << endl;
    
    Book two("for", "auth");
    cout<< two.getAuthor() << endl;
    cout<< two.getTitle() <<endl;
    
    one.setTitle("r");
    one.setAuthor("i");
    cout <<one.getTitle() << endl;
    cout <<one.getAuthor() <<endl;
}
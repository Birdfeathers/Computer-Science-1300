#include <iostream>
#include <fstream>
#include <sstream>
#ifndef USER_H
#define USER_H
#include <iomanip>
using namespace std;

class User
{
    public:
        User();
        User(string us, int ray[], int numratings);
        string getUsername();
        void setUsername(string u);
        int getRatingAt(int position);
        bool setRatingAt(int index, int value);
        int getNumRatings();
        void setNumRatings(int integer);
        int getSize();
    private:
        const int size = 200;
        string username;
        int arr[200];
        int numRatings;
};

#endif
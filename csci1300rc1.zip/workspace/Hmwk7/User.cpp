#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "User.h"
using namespace std;

User ::User()
{
    username = "";
    numRatings = 0;
    for(int i = 0; i < size; i++)
    {
        arr[i] = -1;
    }
}
User ::User(string us, int ray[], int numratings)
{
    username = us;
    numRatings = numratings;
    if(numRatings <= size)
    {
        for(int i =0; i< numRatings; i++ )
        {
            arr[i]= ray[i];
        }
    }
}
string User:: getUsername()
{
    return username;
}
void User:: setUsername(string u)
{
    username = u;
}
int User :: getRatingAt(int position)
{
    if(position >= numRatings && numRatings != 0) return -1;
    return arr[position];
}
bool User::setRatingAt(int index, int value)
{
    if(index < size && value >= 0 && value <= 5)
    {
        arr[index] = value;
        return true;
    }
    else return false;
}
int User:: getNumRatings()
{
    return numRatings;
}
void User:: setNumRatings(int integer)
{
    numRatings = integer;
}
int User::getSize()
{
    return size;
}


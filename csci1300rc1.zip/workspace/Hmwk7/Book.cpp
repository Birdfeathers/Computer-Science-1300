#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Book.h"
using namespace std;

Book :: Book()
{
    title = "";
    author = "";
}

Book :: Book(string t,string a)
{
    title = t;
    author = a;
}

string Book :: getTitle()
{
    return title;
}

void Book :: setTitle(string booktitle)
{
    title = booktitle;
}
string Book :: getAuthor()
{
    return author;
}
void Book :: setAuthor(string bookauthor)
{
    author = bookauthor;
}

// int main()
// {
//     Book one;
//     cout<< "one" << one.getAuthor() << "two" << endl;
//     cout<< "one" << one.getTitle() << "two" << endl;
    
//     Book two("for", "auth");
//     cout<< two.getAuthor() << endl;
//     cout<< two.getTitle() <<endl;
    
//     one.setTitle("r");
//     one.setAuthor("i");
//     cout <<one.getTitle() << endl;
//     cout <<one.getAuthor() <<endl;
// }
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#ifndef BOOK_H
#define BOOK_H
using namespace std;

class Book
{
    public:
        Book();
        Book(string t,string a);
        string getTitle();
        void setTitle(string booktitle);
        string getAuthor();
        void setAuthor(string bookauthor);
    private:
        string title;
        string author; 
};
#endif

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "User.h"
using namespace std;

int main()
{
    User one;
    cout<< one.getUsername()<<endl;
    
    int ray[] = { 0, 1, 2, 3, 4, 5};
    User two("Savanna", ray, 6);
    cout << two.getUsername()<<endl;
    cout << two.getRatingAt(2)<<endl;
    cout << two.getNumRatings()<<endl;
    cout << two.getSize()<<endl;
    
    cout <<two.setRatingAt(2, 3)<< endl;
    cout << two.getRatingAt(2)<<endl;
    cout <<two.setRatingAt(2,7)<<endl;
    
    two.setUsername("go");
    cout <<two.getUsername() << endl;
    two.setNumRatings(8);
    cout << two.getNumRatings()<<endl;
    
    int a[50];
    User three("ro", a, 50);
    cout<<three.setRatingAt(40,3)<<endl;
    cout<<three.getRatingAt(40)<<endl;
    
    cout << three.getRatingAt(9999) << endl;
    three.setRatingAt(0,0);
    cout << three.getRatingAt(0) << endl;
    cout << two.getRatingAt(0) << endl;
    
    
}
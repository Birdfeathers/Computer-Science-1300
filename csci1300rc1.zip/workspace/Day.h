#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#ifndef HOUR_H
#define HOUR_H
using namespace std;

class Hour
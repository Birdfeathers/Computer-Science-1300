#include <iostream>
#include <string>
using namespace std;

void cardSuit(int suitNum)
{
    switch(suitNum)
    {
        case 0: cout << "Suit 0: Clubs"; break;
        case 1: cout << "Suit 1: Diamonds"; break;
        case 2: cout << "Suit 2: Spades"; break;
        case 3: cout << "Suit 3: Hearts"; break;
        default: cout << "Suit " << suitNum << ": Invalid"; break;
        
    }
}


int main()
{
  cardSuit(0);
  cardSuit(1);
  cardSuit(2);
  cardSuit(3);
  cardSuit(4);

}
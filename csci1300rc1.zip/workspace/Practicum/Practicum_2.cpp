#include <iostream>
#include <string>
using namespace std;

string mileage(int flight)
{
    if(flight < 0) return "INVALID";
    else if (flight <= 10000) return "Bronze";
    else if (flight <= 15000) return "Silver";
    else if (flight <= 30000) return "Gold";
    else return "Platinum";
}


int main()
{
    cout << mileage(12000);

}
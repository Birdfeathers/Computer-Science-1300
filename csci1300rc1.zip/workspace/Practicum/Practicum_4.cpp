#include <iostream>
#include <string>
using namespace std;

double largestNumber(double num1, double num2, double num3)
{
    double largest = num1;
    if (num2 > num1) largest = num2;
    if (num3 > largest) largest = num3;
    return largest;
}


int main()
{
   cout << largestNumber(4, 9, 2.5) ;
   cout <<largestNumber(12.3, 8, 12.3);

}
#include <iostream>
#include <string>
using namespace std;

int solarCharge(int minutes)
{
   int percent = minutes/2;
   if(percent > 100) percent = 100;
   return percent;
}



int main()
{
    cout << solarCharge(11) << endl;
    cout << solarCharge(30) <<endl;
    cout << solarCharge(230) << endl;

}
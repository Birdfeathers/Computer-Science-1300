#include <iostream>

using namespace std;

int main()
{
int counter = 1;
while (counter <= 100)
{
    if(counter%15 == 0)
    {
        cout << "fizzbuzz ";
    }
    else if (counter%3 ==0)
    {
        cout << "fizz ";
    }
    else if(counter%5 ==0)
    {
        cout << "buzz ";
    }
    else
    {
        cout << counter << " ";
    }
    counter++;
}
}

#include <iostream>

using namespace std;

// do loop exectutes statements at least once

//do
//{
   //statements
//}
//while("condition"); // put semicolon at the end


int main()
{
    string name = "Harry";
    string lastname= " Potter";
    string fullname = name + lastname;// at least one variable, rest can be literal strings
    cout << fullname;
    int n =name.length();
    cout<<n;
    cout << name[1];
    // can add strings together- concatonate
    
    //substrings
}
//user input only works up to a space
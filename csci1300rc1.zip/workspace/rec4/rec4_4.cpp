// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 4-Problem 4

#include <iostream>

using namespace std;

void printDiamond(int sidelength)
{
    int linemax= sidelength * 2 - 1;
    int line = 1;
    while(line <= (1+linemax)/2)
    {
        int centerstar = 1 + 2 * (line - 1);
        int spacenumber = (linemax - centerstar)/2;
        int firstspacecount = 1;
        while (firstspacecount <= spacenumber)
        {
            cout << " ";
            firstspacecount++;
        }
        int starcount =1;
        while (starcount <= centerstar)
        {
            cout << "*";
            starcount++;
        }
        line++;
        cout <<endl;
    }
    while ((line > ((1+linemax)/2)) && line <= linemax)
    {
        int centerstar = 1 + 2*(linemax-line);
        int spacenumber = (linemax-centerstar)/2;
         int firstspacecount = 1;
        while (firstspacecount <= spacenumber)
        {
            cout << " ";
            firstspacecount++;
        }
        int starcount =1;
        while (starcount <= centerstar)
        {
            cout << "*";
            starcount++;
        }
        line++;
        cout <<endl;
    }
}

int main()
{
    printDiamond(4);//test numbers
    printDiamond(1);
    printDiamond(0);//test 0
    printDiamond(2);
    printDiamond(10);
    printDiamond(20);
}
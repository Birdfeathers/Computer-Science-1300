// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 4-Problem 1

#include <iostream>

using namespace std;

void printEvenNums(int max)
{
   int number = 2;
    while (number <= max)
    {
        cout << number << " ";
        number = number + 2;//counts up by 2
    }
}

int main()
{
    printEvenNums(10);//test at ten
    printEvenNums(0);//test at zero
}
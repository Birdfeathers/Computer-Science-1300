// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 4-Problem 2

#include <iostream>

using namespace std;

void printMultiples(int multiply, int max)
{
   int number = multiply;
   while (number <= max)
   {
       cout << number << endl;
       number = number + multiply;
   }
}

int main()
{
    printMultiples(3, 10);// test function
    printMultiples(3, 0);// test when max is zero
    printMultiples(5, 4);// test when max greater than integer
    //printMultiples(0, 1);// test loop- infinite
}

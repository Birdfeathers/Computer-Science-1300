// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 4-Problem 3

#include <iostream>

using namespace std;

void printSquares(int width)
{
    int line = 1;
    while (line <= width)
    {
        int starcounter= 1;
        while (starcounter <= width)
        {
            cout<< "*";
            starcounter++;
        }
        cout << " ";
        int spacecounter=1;
        while (spacecounter <= width)
        {
            if ((spacecounter == 1 || spacecounter == width)||(line == 1||line == width) )
            {
                cout << "*";
            }
            else
            {
                cout << " ";
            }
            spacecounter++;
        }
        cout << endl;
        line++;
    }
}

int main()
{
    printSquares(5);
    printSquares(0);
    printSquares(10);
}
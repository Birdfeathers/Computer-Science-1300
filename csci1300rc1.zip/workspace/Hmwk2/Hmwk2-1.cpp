// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 2 - Problem # 1

#include <iostream>

using namespace std;


/* Algorithm: convert seconds to hours, minutes, and seconds
1. define the varible seconds as an integer
2. tell user to assign how many seonds
3. From seconds calculate hours by dividing seconds by 3600.  Define hours as an integer so any seconds that do not divide evenly will be truncated.
4. Calculate minutes that aren't accounted for in hours by:
    a) first subtracting 3600*hours from seconds to find the number of seconds not accounted for in hours
    b) dividing the remaining seconds by 60 to find the number of minutes and defining minutes as an integer to truncate the remainder. 
5. Calculate seconds not accounted for by hours and minutes by subtracting (3600*hours) and (60*minutes) from seconds. Assign this as the new seconds value.
6. Output the number of hours, seconds, and minutes in the desired format.
Note: I’m assuming these variables are in integer form so it would truncate any decimal

*/

void convertSeconds(int seconds)//convert seconds into hours, minutes, and seconds
{   
    int hours = seconds / 3600; // when dividing integers it will only include integers that divide evenly in the result
    int minutes = (seconds - (3600 * hours))/ 60;// find number of minutes from remaining seconds
    seconds = seconds - (3600 * hours) - (60 * minutes);//reassign value seconds to seconds which are left over
    cout << hours << " hour(s) " << minutes << " minute(s) " << seconds << " second(s)"<< endl;
}

int main() 
{
   cout << "5403 seconds is equivalent to ";
   convertSeconds(5403); // test conversion with 5403 seconds
   cout << "24000 seconds is equivalent to ";
   convertSeconds(24000); //test conversion with 24000 seconds
}
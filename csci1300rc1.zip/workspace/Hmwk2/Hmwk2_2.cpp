// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 2 - Problem # 2

#include <iostream>
#include <iomanip>
using namespace std;


/* Algorithm: convert Celcius(C) to Farenheight(F) = C*(9/5) + 32
celcius= input(“What is the temperature in degrees celcius?”)
F = C*(9/5) +32
output(farenheight)
*/

void  celsiusToFahrenheit(double celsius)
{
 double fahrenheit = (celsius * (9.0/5.0)) + 32; // equation converting celsius to farenheight
 cout << "The temperature of "<<celsius<<" in farhenheit is "<< fixed << setprecision(2)<< fahrenheit <<endl;
}

int main()
{
    celsiusToFahrenheit(38);//testing conversion to farenheight when celsius=38
    celsiusToFahrenheit(100);//testing conversion to farenheight when celsius=100
    celsiusToFahrenheit(-40);//testing conversion to farenheight when celsius=-40
}
// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 2 - Problem # 3

#include <iostream>

using namespace std;

/* Algorithm: calculate US population after one year
    1.input initial population
    2. Add the number of births in one year, one person is born every 8 seconds: 
    population= initial population+(31536000)/8
    3. Subtract number of deaths in one year, one person dies every 12 seconds:
    population= population - (31536000)/12
    4. Add the number of immigrants per year, one person immigrates every 27 seconds:
    population = population + (3156000)/27
    5. return new population value
    
    	*/

int population(int inital_population)
{
 int population = inital_population + (31536000/8);// adding number of births to initial population
 population = population - (31536000/12); // subtracting number of deaths from population
 population = population + (31536000/27); // adding numbers of immigrants to population
 
 return population;
   
}

int main()
{
  cout<<"If the initial population is 1000000 the population after one year will be "<< population(1000000)<<endl;// test for when population is 1000000
  
  cout<<"If the initial population is 0 the population after one year will be "<< population(0); // test for when population is 0
}
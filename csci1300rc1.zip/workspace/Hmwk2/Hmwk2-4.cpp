// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 2 - Problem # 4

#include <iostream>

using namespace std;

/* Algorithm: calculate value for luminosity L = 4bπdd
    1. receive input argument values for distance(d) and brightness(b)
    2. calculate value of luminosity from equaltion L = 4bπdd with π=3.14159 
    3. return value of luminosity as an integer
*/

double luminosity(double brightness, double distance)
{
    int luminosity = 4 * brightness * 3.14159 * distance * distance; //equation for luminosity
    return luminosity;
}

int main ()
{
   cout <<"The value of luminosity when brightness equals 1.5 and distance equals 17.8 is " << luminosity(1.5, 17.8)<< endl; // test with brightness=1.5, distance= 17.8
   cout <<"The value of luminosity when brightness equals 1 and distance equals 1 is " << luminosity(1,1); // test with brightness=1, distance= 1
   
}
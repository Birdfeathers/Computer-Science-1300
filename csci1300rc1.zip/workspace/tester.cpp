#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

class Car
{
   void start();
   double speed;
   double get_speed() const;
};

void Car :: start()
{
   cout << "x";
}

int main()
{
   Car one;
   one.start();
}
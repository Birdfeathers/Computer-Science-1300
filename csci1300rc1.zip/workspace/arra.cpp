#include <iostream>
using namespace std;

int main()
{  
   const int CAPACITY = 10;
   double values[CAPACITY];
   int size = 10;
   
   for (int i = 0; i < size; i++)
   {
      values[i] = 0;
   }

   
   return 0;
}
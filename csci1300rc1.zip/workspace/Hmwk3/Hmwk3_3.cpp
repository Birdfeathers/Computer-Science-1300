// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 3 - Problem # 3

#include <iostream>

using namespace std;

/* Algorithm: print out the number of days in a month
1. create a switch within the function that takes in the number of the month
2. for each month 1-12 create a case that prints out the number of days for the month the argument matches in the follwing form:
"Month (input argument) has (number of days in month) days"
3. create a default case in case someone uses an input argument that isn't one of the 12 months which prints:
"Invalid month number"
*/

void daysOfMonth(int month)
{
 switch(month)//input month number
 {
    case 1: cout << "Month 1 has 31 days";// prints number of days for January
    break;
    case 2:cout << "Month 2 has 28 or 29 days";//prints number of days for February
    break;
    case 3:cout << "Month 3 has 31 days";// prints number of days for March
    break;
    case 4:cout << "Month 4 has 30 days";// prints number of days for April
    break;
    case 5:cout << "Month 5 has 31 days";// prints number of days for May
    break;
    case 6:cout << "Month 6 has 30 days";// prints number of days for June
    break;
    case 7:cout << "Month 7 has 31 days";// prints number of days for July
    break;
    case 8:cout << "Month 8 has 31 days";// prints number of days for August
    break;
    case 9:cout << "Month 9 has 30 days";// prints number of days for September
    break;
    case 10:cout << "Month 10 has 31 days";// prints number of days for October
    break;
    case 11:cout << "Month 11 has 30 days";// prints number of days for November
    break;
    case 12:cout << "Month 12 has 31 days";// prints number of days for December
    break;
    default: cout << "Invalid month number";// responds to invalid argument
 }
    
}

int main()
{
    daysOfMonth(4);// test month 4
    daysOfMonth(2);// test month 2
    daysOfMonth(13);// test invalid month number 13
    daysOfMonth(0);// test invalid month number 0
}
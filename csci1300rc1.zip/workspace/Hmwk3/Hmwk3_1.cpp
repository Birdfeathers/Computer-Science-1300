// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 3 - Problem # 1

#include <iostream>

using namespace std;

/* Algorithm: return: n/2 for even pos values, 3n + 1 for odd pos values, 0 for neg values
Within function collatzstep(input: number)
1. make a conditional for positive, even numbers(greater than 0 and divisiable by 2) that returns the number/2
2. make a conditional for positive, odd numbers(greater than 0 and not divisable by 2) that returns (3number +1)
3. make a conditional for negative numbers(less than or equal to 0, the value returned by input of 0 would be 
the same whether it's considered pos or neg) that returns 0
*/

double collatzStep(int number)
{
    if(number > 0 && number % 2 == 0)//takes in pos numbers divisable by 2
    {
        int output= number/2;//returns the number divided by 2
        return output;
    }
    if (number > 0 && number % 2 != 0)// takes in pos numbers not divisable by 2
    {
        int output = (3 * number) + 1;// returns 3 times the number plus one
        return output;
    }
    if (number <= 0)//takes in neg numbers
    {
        return 0;//returns 0
    }
}

int main()
{
    cout << "If n is 4 collatzStep returns " << collatzStep(4) << endl;//test pos, even number
    cout << "If n is 7 collatzStep returns " << collatzStep(7) << endl;//test pos, odd number
    cout << "If n is -5 collatzStep returns " << collatzStep(-5) << endl;//test neg number
    cout << "If n is 0 collatzStep returns " << collatzStep(0) << endl;//test zero
}
// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 3 - Problem # 4 (Extra Credit)

#include <iostream>

using namespace std;

/* Algorithm: test if door of van will open
1. accept nine values into function "vehicle"
2. create a condition for when the masterlock is open and gearshift is in 'P'(these conditions must be met for doors to open)
    within this condition
    a. if ((outside left door is pulled or the left dash is pressed) or (inside left door is pulled and the child lock is off)) and 
    ((outside right door is pulled or the right dash is pressed) or (inside right door is pulled and the child lock is off)) print "Both doors open"
    b. otherwise, if (outside left door is pulled or the left dash is pressed) or (inside left door is pulled and the child lock is off)
      print "Left door opens"
    c. otherwise, if (outside right door is pulled or the right dash is pressed) or (inside right door is pulled and the child lock is off)
      print "Right door opens"
    d. otherwise, print "Both doors stay closed"
3. Otherwise, print "Both doors stay closed"

*/

void vehicle(bool DashLeft, bool DashRight, bool ChildLock, bool MasterLock, bool insideLeft, bool outsideLeft, bool insideRight, bool outsideRight, char gearshift)
{
    if (MasterLock==0 && gearshift == 'P')//conditions necessary for doors to open
    {
        if (((outsideLeft == 1 || DashLeft ==1)||(insideLeft==1 && ChildLock== 0)) && ((outsideRight == 1 || DashRight==1)||(insideRight==1 && ChildLock== 0)))
        {
          cout << "Both doors open" << endl;// check both doors
        }
        else if ((outsideLeft == 1 || DashLeft ==1)||(insideLeft==1 && ChildLock== 0))//check left door
            {
                cout << "Left door opens" << endl; 
            }
        else if((outsideRight == 1 || DashRight==1)||(insideRight==1 && ChildLock== 0))//check right door
        {
            cout << "Right door opens" << endl;
        }
        else
        {
            cout << "Both doors stay closed" << endl;//neither have conditions to open
        }
    }
   else
    {
        cout << "Both doors stay closed" << endl;// masterlock or gearshift in wrong position prevent opening
    }
}

int main()
{
    cout <<"if the inside right handle is pullled, outside left handle is pulled, child lock is on, master lock is off and gear shift is in P then ";
    vehicle(0,0,1,0,0,1,1,0,'P'); //test example from Hmwk write up
    // test everything open
    cout << "when everything is unlocked but no one is trying to open it ";
    vehicle(0,0,0,0,0,0,0,0,'P');// test when locks are open, but no one trying to open it
    // test everything closed
    cout << "when all car is locked but you try to open car ";
    vehicle(1,1,1,1,1,1,1,1,'P');// test when try to open, but it's locked
    cout << "when childlock is on and you open from the right dash ";
    vehicle(0,1,1,0,0,0,0,0, 'P');//test that it opens from the right dash
    cout << "when you open both doors all ways ";
    vehicle(1,1,0,0,1,1,1,1,'P');// test when both doors open
    cout << "when you try to open the car but it is not in park ";
    vehicle(1,1,0,0,1,1,1,1,'N');// test when not in park
}
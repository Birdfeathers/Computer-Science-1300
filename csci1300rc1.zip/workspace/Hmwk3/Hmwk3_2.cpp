// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 3 - Problem # 2

#include <iostream>

using namespace std;

/* Algorithm: count the number of digits in the input
1. take in a number in the function integer form
2. If the number divided by ten equals zero, return 1, since the number is in integer form if it is less than ten dividing it by 10 will return 0.
Therefore, it will be a 1 digit number.
3.Otherwise, if the number divided by 100 equals zero, return 2, since the number is in integer form if it is less than 100 dividing it by 100 will return 0.
Therefore, it will be a 2 digit number.
4.Otherwise, if the number divided by 1000 equals zero, return 3, since the number is in integer form if it is less than 1000 dividing it by 1000 will return 0.
Therefore, it will be a 3 digit number.
5. Otherwise return 4
*/

int countDigits(int number)
{
    if (number/10 == 0)//applies to numbers less than 10(or greater than -10)
    {
        return 1;// one digit
    }
        else if (number/100 == 0)//applies to numbers less than 100(or greater than -100)
        {
            return 2;//two digits
        }
            else if (number/1000 == 0)//applies to numbers less than 1000(or greater than -1000)
            {
                return 3;//three digits
            }
                else
                {
                    return 4;
                }
}

int main()
{
    cout << "123 has " << countDigits(123) <<" digits" <<endl;// testing a three digit number
    cout << "-75 has " << countDigits(-75) <<" digits" <<endl;// testing a two digit neg number
    cout << "1 has " << countDigits(1) <<" digits" <<endl;// testing a one digit number
    cout << "0 has " << countDigits(0) <<" digits" <<endl;// testing 0
}
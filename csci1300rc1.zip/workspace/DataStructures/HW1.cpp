#include<iostream>
using namespace std;
#include <string>
#include <fstream>



int insertIntoSortedArray(int myArray[], int numEntries, int newValue)
{
  for(int i = 0; i < numEntries; i++)
  {
    if(myArray[i] > newValue)
    {
     for(int j = numEntries; j > i; j--)
     {
       myArray[j] = myArray[j-1];
     }
      myArray[i] = newValue; 
      return numEntries + 1;
    }
  }
  myArray[numEntries] = newValue;
  return numEntries +1;
}

// int main ( int argc, char const *argv[])
// {
//   ifstream read;
//   read.open(argv[1]);
//   if(!read.is_open()) cout << "Failed to open the file" <<endl;
//   string number;
//   for(int i = 0; i < 100; i++)
//   {
//     getline(read, number);
//     int newValue = stoi(number);
    
  
//   }


// }
int main ()
{
  ifstream read;
  read.open("numbers.txt");
  if(!read.is_open()) cout << "Failed to open the file" <<endl;
  string number;
  int myarray[100];
  for(int i = 0; i < 62; i++)
  {
    getline(read, number);
    int newValue = stoi(number);
    insertIntoSortedArray(myarray, i, newValue);
    for(int j = 0; j < i+1; j++)
    {
      
      cout << myarray[j] << ",";
    }
    cout << endl;
  
  }
  cout << "end" <<endl;
}

// int main()
// {
//   int array[100];
//   array[0] = 1;
//   array[1] = 45;
//   array[2] = 60;
//   array[3] = 63;
//   array[4] = 100;
//   insertIntoSortedArray(array, 5, 60);
//   for(int i = 0; i < 6; i++)
//   {
//     cout<< array[i] <<endl;
//   }
// }
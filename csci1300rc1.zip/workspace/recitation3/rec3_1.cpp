#include <iostream>
using namespace std;

void numberSign(int number)
{
    if (number<0)
    { 
        cout << "negative";
    }
    if (number>0)
    {
        cout << "positive";
    }
    if (number == 0)
    {
        cout << "zero";
    }
}

int main()
{
    numberSign(3);
    numberSign(-3);
    numberSign(0);
}
#include <iostream>
using namespace std;

double calcPay(double hours_worked,double hourly_pay)
{
    if (hours_worked < 0 || hourly_pay < 0)
    {
        return -1;
    }
    else if (hours_worked<= 40)
        {
        double total_pay = hours_worked * hourly_pay;
        return total_pay;
        }
        else
            {
             double overtime = hours_worked - 40;
             double total_pay = (40 * hourly_pay) + (overtime * 1.5 * hourly_pay);
             return total_pay;
            }
    
}

int main()
{
    cout << calcPay(41, 10)<< endl;
    cout << calcPay(1,1)<<endl;
    cout << calcPay(-1,-1)<< endl;
    
}
#include <iostream>
using namespace std;

bool  checkLeapYear(int year)
{
    if (((year % 4 ==0)&& (year <=1582))|| (((year % 4 == 0)&&((year %100) != 0)|| (year%400 == 0))))
    { 
        return 1;
    }
        else
        {
            return 0;
        }
}

int main()
{
    cout << checkLeapYear(1900)<< endl;
    cout << checkLeapYear(2000)<< endl;
    
}
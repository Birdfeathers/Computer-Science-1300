#include <iostream>
#include <string>
using namespace std;

void replaceNums(int arr[], int length)
{
    int arr2[length];
    arr2[0] = arr[0];
    arr2[length-1]= arr[length-1];
    for(int i=1; i < length-1; i++)
    {
        if(arr[i-1] > arr[i+1]) arr2[i] = arr[i-1];
        else arr2[i] = arr[i+1];
    }
    for(int j = 0; j < length; j++)
    {
        arr[j]= arr2[j];
    }
}

int main()
{
    int bar[5] = {1,2,3,4,5};
    replaceNums(bar, 5);
    cout<< bar[0]<< bar[1]<< bar[2]<<bar[3]<< bar[4];
}
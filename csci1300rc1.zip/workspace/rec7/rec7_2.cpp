#include <iostream>
#include <string>
using namespace std;

void printTwoDArray(int arr2d[][5], int length)
{
   if(length == 0) cout<< 0;
   if(length < 0) cout<< -1;
   for(int i=0; i < length; i++)
   {
       for(int j= 0; j<5 ; j++)
       {
           cout<<arr2d[i][j];
           if(j != 4)cout<< ",";
       }
       cout<< endl;
   }
}

int main()
{
    int myArray[3][5] = {{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}};
    printTwoDArray(myArray, 3);
}
#include <iostream>
#include <string>
using namespace std;

void floodMap(double map[][4], int rows, double waterlevel)
{
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            if(map[i][j] <= waterlevel) cout << "*";
            else cout<< "_";
        }
        cout<< endl;
    }
}

int main()
{
    // double map[2][4] = {{0.2, 0.8, 0.8, 0.2},
    // {0.2, 0.2, 0.8, 0.5}};
    // floodMap(map, 2, 1.0);
    double map[2][4] = {{0.2, 0.8, 0.8, 0.2},
    {0.2, 0.2, 0.8, 0.5}};
    floodMap(map, 2, 0.5);

}
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int getLinesFromFile(string filename, int arr[], int arrlength)
{
    ifstream file;
    file.open(filename);
    if(file.is_open()== 0)
    {
        return -1;
    }
    int entry = 0;
    for(int i=0; i < arrlength; i++)
    {
        string line= "";
        getline(file, line);
        if(line.length() != 0)
        {
            int r = stoi(line);
            arr[entry]= r;
            entry++;
        }
    }
    return entry;
    
}

int main()
{
    int arr[4];
    cout<< getLinesFromFile("fileName.txt", arr, 4);
}
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

int readRatings(string file_name, string usernames[], int userratings[][50], int currently, int rowcap, int columcap)
{
    ifstream ratings;
    ratings.open(file_name);
    if(!ratings.is_open()) return -1;
    string line;
    int user = currently;
    while(getline(ratings,line)&& user < rowcap)
    {
        string name = "";
        int i = 0, linelength = line.length(), counter = 0;
        for(i; line[i] != ','; i++)
        {
            name = name + line[i];
        }
         for(i++; i < linelength; i++)
        {
            if(line[i] != ' ')
            {
                string rating =  line.substr(i, 1);
                int rate = stoi(rating);
                userratings[user][counter]= rate;
                counter++;
            }
        }
        usernames[user]= name;
        user++;
        cout << name << "..." << endl;
        
    }
    return user;
}

void instring()
{
    string gar;
    cin >> gar;
    cout << gar;
}

int main()
{
    // string usernames[150];
    // int ratings[150][50];
    // cout<<readRatings("ratings.txt",usernames, ratings, 0, 150, 150);
    // cout<< usernames[29]<< endl << ratings[0][5];
    instring();
}
// CSCI1300 Fall 2018
// Author: Rebecca Carr
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// hmwk6 


#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;
/* Algorithm: Reading data
function: readbooks
1. open the readbooks file. if unsuccesful return -1.
2.take in one line at a time and:
    a. create a string for the author's name by concatonating every letter from the start to the comma.
    b. after the comma concatonate every letter until the end into another string to get the title
    c. place title and author string into their respective arrays. 
3. return number of books at the end. 

function: readRatings
1. open the ratings file, if unsuccessful return -1. 
2. take in one line at a time and:
    a. concatonate letters until the comma for a string with the username
    b. after the comma, when the program comes across ratings(characters that are not spaces)
        i) convert them to strings, then integers
        ii) store them in the 2d integer array
    c. place the string for usernames the username array
3. return the number of users

function: printAllBooks
1. if the number of books is zero, print, "No books are stored"
2. Otherwise 
    a. print ,"Here is a list of books"
    b. for each position in the arrays print (title at that position)" by "(author at that position)

function: getReadCout
1. call a helper function to return the user index
2. If user is not found by helper function, print the user doesn't exist return -1
3. use a loop that goes from zero until the end of the array size, at the position of the user and where the loop
is in the 2d array, add 1 to a count interval if the users score is not zero(meaning they read the book)
4. return the count variable

function : calcAverg
1. call a helper function to return the book index. 
2. If book is not found in the function print that it does not exist, return -1.
3. use a loop that trnverses the 2d array for a set book. when a rating does not equal zero(meaning they read the book):
    a. add the rating to a variable rep total ratings
    b. increase by 1 a variable that counts the number of ratings. 
4. calculate the average by dividing the total by the number of ratings
5. return the average. 

/* readBooks function
 * the function reads a book file from the text into book and author arrays
 *
 * @param: string, the name of the file to be read
 * @param: string array, titles
 * @param: string array, authors
 * @param: int, the number of books currently stored in the arrays
 * @param: int, capacity of the authors/titles arrays [assume to be 50]
 * @return: the total number of books in total
 */
 

//////////////////////////////////////////////////////////////////////////
// ToDo: implement readBooksfunction
// your readBooks function goes here
int readBooks(string file_name, string titles[], string authors[], int numbooks, int capacity)
{
    ifstream readbook; // declares fstream variable
    readbook.open(file_name); // opens file function was fed
    if(!readbook.is_open()) return -1; // returns -1 is can't access file
    string line; // to be given the lines of code
    int booknumber = numbooks; // number of books filled so far- fill from here
    while(getline(readbook,line) && booknumber < capacity)// while the document isn't empty & still room
    {
        int linelength = line.length();
        string author= "", title= "";
        int i = 0;
        for(i; line[i] != ','; i++) // gets up to the comma- author's name
        {
            author = author + line[i]; // concatonates name one letter at a time
        }
        for(i++; i < linelength; i++) // continues after the comma- title
        {
            title = title + line[i]; // concatonates title
        }
        authors[booknumber] = author; // puts it into author array at the book number position
        titles[booknumber]= title; // puts it into title array at the book number position
        booknumber++; // moves to next position in array
    }
    return booknumber; // returned how far it goes until
}

//////////////////////////////////////////////////////////////////////////


/* readRatings function
 * Read the user ratings from the file and store them
 * into users array and ratings array
 *
 * @param: string, the name of the file to be read
 * @param: string array, usernames
 * @param: 2D int array, list of ratings for each user (first index specifies user)
 * @param: int, the number of users currently stored in the array
 * @param: int, row capacity of the 2D array (convention: array[row][column]) [assume to be 100]
 * @param: int, column capacity of the 2D array [assume to be 50]
 * @return: the number of users in total
 */

 //////////////////////////////////////////////////////////////////////////
 // ToDo: implement readRatings function
 // your readBooks function goes here
int readRatings(string file_name, string usernames[], int userratings[][50], int currently, int rowcap, int columcap)
{
    ifstream ratings; // variable for ratings file
    ratings.open(file_name); // open ratings file with it's name
    if(!ratings.is_open()) return -1; // returns -1 if file could not be open
    string line; // variable to be given lines
    int user = currently; // sets the user it starts on with the number of users already filled
    while(getline(ratings,line)&& user < rowcap)// while still lines to get & room in array
    {
        string name = "";
        int i = 0, linelength = line.length(), counter = 0;
        for(i; line[i] != ','; i++) // gets username before comma
        {
            name = name + line[i];// concatonates username
        }
         for(i++; i < linelength; i++) // gets scores after username
        {
            if(line[i] != ' ') // numbers are at positions where there are not spaces
            {
                string rating =  line.substr(i, 1);// the rating must be converted to a string
                int rate = stoi(rating); // next, converted to an integer
                userratings[user][counter]= rate; // now stored in the array
                counter++; // inc so next colmumn in array will be used for next int
            }
        }
        usernames[user]= name; // at the end the line, we can put the username in the username array
        user++; // move to next user
        cout << name << "..." << endl; // prints names as they are added
        
    }
    return user;
}
 //////////////////////////////////////////////////////////////////////////


 //////////////////////////////////////////////////////////////////////////
 // other helper functions
 void printAllBooks(string titles[], string authors[], int numbooks)
{
    if(numbooks <= 0) cout<< "No books are stored" << endl; // equals zero or -1 before arrays formed
    else
    {
        cout<< "Here is a list of books"<<endl;
        for(int i=0; i < numbooks; i++)
        {
            cout << titles[i] << " by " << authors[i] << endl;// prints matching elements of arrays
        }
    }
}

int searchuser(string username, string allusers[],int numusers) // helper function for getUserReadCount
{
    for(int i = 0; i < numusers ; i++)
    {
        if(username == allusers[i]) return i; // returns the index for the user once a match is found
    }
    return -1;// meaning it failed to find the username after traversing whole array
}


int getUserReadCount(string username, string allusers[],int userratings[][50], int numusers, int numbooks)
{
    int usernumber = searchuser(username, allusers, numusers);
    if(usernumber == -1) // helper function failed to find user
    {
        cout<< username << " does not exist in the database" << endl;
        return -1; 
    }
    int counter = 0; // counts number of books
    for(int i= 0; i < numbooks; i++)
    {
        if(userratings[usernumber][i] != 0) // zero indicating they did not read the books
        {
            counter++;
        }
    }
    
    return counter;
}

int searchbook(string title, string titles[],int books) // helper function for calcAvgRating
{
    for(int i = 0; i < books ; i++)
    {
        if(title == titles[i]) return i; // if the title given matches the entry at the index, return the index
    }
    return -1;// meaning it failed to find the book
}
double calcAvgRating(string title, string titles[], int userratings[][50],int numusers, int numbooks)
{
    int booknumber = searchbook(title, titles, numbooks);
    if(booknumber == -1) // meaning helper function could not find it
    {
        cout<< title << " does not exist in our database" << endl;
        return -1;
    }
    double total = 0, number= 0; //total keeps track of all ratings added together, number keeps track of number of ratings
    for(int i=0; i < numusers; i++)
    {
        if(userratings[i][booknumber] != 0) // zero indicates they haven't read it, so only nonzeros should count
        {
            total = total + userratings[i][booknumber]; // adding rating to total
            number++; // keeping track og number of ratings
        }
    }
    double average = total / number; //finds mean
    return average;
}
 

 //////////////////////////////////////////////////////////////////////////



/* displayMenu:
 * displays a menu with options
 * DO NOT MODIFY THIS FUNCTION
 */
void displayMenu(){
  cout << "Select a numerical option:" << endl;
  cout << "======Main Menu=====" << endl;
  cout << "1. Read book file" << endl;
  cout << "2. Read user file" << endl;
  cout << "3. Print book list" << endl;
  cout << "4. Find number of books user rated" << endl;
  cout << "5. Get average rating" << endl;
  cout << "6. Quit" << endl;
}


int main(int argc, char const *argv[]) {
    string choice;
    int numBooks = 0;
    int numUsers = 0;
    // initializing variables
    string titles[50];
    string authors[50];
    string usernames[150];
    int userratings[150][50];
    // intializing all arrays to be used later

    while (choice != "6") {
            displayMenu();
            getline(cin, choice);
            switch (stoi(choice)) {
                case 1:
                    // read book file
                    cout << "Enter a book file name:" << endl;
                    
                    //////////////////////////////////////////////////////////////////////////
                    // Your code here. Call the appropriate function(s).
                    getline(cin, choice); // takes in user input for file name
                    numBooks = readBooks(choice,titles,authors, 0, 50); // chould return number of books 
                    //////////////////////////////////////////////////////////////////////////
                    if(numBooks == -1)cout<< "No books saved to the database" << endl;// means it could not be opened
                    else cout << "Total books in the database: " << numBooks << endl;
                    cout << endl;
                    break;

                case 2:
                    // read user file
                    cout << "Enter a rating file name:" << endl;

                    //////////////////////////////////////////////////////////////////////////
                    // Your code here. Call the appropriate function(s).
                     getline(cin, choice); // gets user input about file name
                     numUsers = readRatings(choice, usernames, userratings, 0, 150, 50); // should return the number of users
                    //////////////////////////////////////////////////////////////////////////
                    if(numUsers ==-1) cout<< "No users saved to database" <<endl; // returns when file cannot be opened
                    else cout << "Total users in the database: " << numUsers << endl;
                    cout << endl;
                    break;

                case 3:
                    // print the list of the books
                    
                    //////////////////////////////////////////////////////////////////////////
                    // Your code here. Call the appropriate function(s).
                    printAllBooks(titles, authors, numBooks); // should diplay everything it needs to
                    //////////////////////////////////////////////////////////////////////////
                    
                    cout << endl;
                    break;

                case 4:
                    // find the number of books user read
                    cout << "Enter username:" << endl;
                    
                    //////////////////////////////////////////////////////////////////////////
                    // Your code here. Call the appropriate function(s).
                    getline(cin, choice); // gets user input on username
                    if(getUserReadCount(choice, usernames, userratings,numUsers, numBooks)== -1); // function call prints what it needs to when user can't be found
                    else
                    {
                        cout << choice <<" rated ";
                        cout<<getUserReadCount(choice, usernames, userratings,numUsers, numBooks);
                        cout << " books";
                        cout << endl; // cout this phrase
                    }
                    //////////////////////////////////////////////////////////////////////////
                    
                    cout << endl;
                    break;

                case 5:
                    // get the average rating of the book
                    cout << "Enter book title:" << endl;

                    //////////////////////////////////////////////////////////////////////////
                    // Your code here. Call the appropriate function(s).
                    getline(cin, choice); // takes in user input about title
                    if(calcAvgRating(choice, titles, userratings, numUsers , numBooks)== -1); // function outputs what it needs to if title is incorrect
                    else
                    {
                        cout <<"The average rating for " << choice <<" is ";
                        cout<<fixed << setprecision(2) <<calcAvgRating(choice, titles, userratings, numUsers , numBooks);
                        cout << endl; // prints this phrase with exactly two decimal points on the variable average
                    }
                    //////////////////////////////////////////////////////////////////////////
                    
                    cout << endl;
                    break;
                case 6:
                    // quit
                    cout << "good bye!" << endl;
                    break;

                default:
                    cout << "invalid input" << endl << endl;
            }
    }

    return 0;
}
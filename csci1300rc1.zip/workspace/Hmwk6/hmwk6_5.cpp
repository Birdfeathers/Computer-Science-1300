#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

int readRatings(string file_name, string usernames[], int userratings[][50], int currently, int rowcap, int columcap)
{
    ifstream ratings;
    ratings.open(file_name);
    if(!ratings.is_open()) return -1;
    string line;
    int user = currently;
    while(getline(ratings,line)&& user < rowcap)
    {
        string name = "";
        int i = 0, linelength = line.length(), counter = 0;
        for(i; line[i] != ','; i++)
        {
            name = name + line[i];
        }
         for(i++; i < linelength; i++)
        {
            if(line[i] != ' ')
            {
                string rating =  line.substr(i, 1);
                int rate = stoi(rating);
                userratings[user][counter]= rate;
                counter++;
            }
        }
        usernames[user]= name;
        user++;
        cout << name << "..." << endl;
        
    }
    return user;
}

int searchuser(string username, string allusers[],int numusers)
{
    for(int i = 0; i < numusers ; i++)
    {
        if(username == allusers[i]) return i;
    }
    return -1;// meaning it failed to find the username
}



int getUserReadCount(string username, string allusers[],int userratings[][50], int numusers, int numbooks)
{
    int usernumber = searchuser(username, allusers, numusers);
    if(usernumber == -1)
    {
        cout<< username << " does not exist in the database" << endl;
        return -1;
    }
    ifstream ratings;
    ratings.open("ratings.txt");
    string line;
    for(int k=0; k != usernumber+1; k++)getline(ratings, line); 
    int linelength = line.length();
    int counter = 0;
    for(int i = 0; i < linelength; i++)
    {
        if(line[i] >= '0' && line[i] <= '5') counter++;
    }
    return counter;
}

int searchbook(string title, string titles[],int books)
{
    for(int i = 0; i < books ; i++)
    {
        if(title == titles[i]) return i;
    }
    return -1;// meaning it failed to find the book
}

double calcAvgRating(string title, string titles[], int userratings[][50],int numusers, int numbooks)
{
    int booknumber = searchbook(title, titles, numbooks);
    if(booknumber == -1)
    {
        cout<< title << " does not exist in the database" << endl;
        return -1;
    }
    double total = 0, number= 0;
    for(int i=0; i < numusers; i++)
    {
        string name= usernames[i];
        if(userratings[i][booknumber] != 0)
        {
            total = total + userratings[i][booknumber];
            number++;
        }
    }
    double average = total / number;
    return average;
}

int main()
{
    string usernames[150];
    int ratings[150][50];
    
    readRatings("ratings.txt",usernames, ratings, 0, 150, 150);
    cout<< getUserReadCount("dorothy", usernames, ratings, 150, 50);
    //cout<< ratings[2][49];
    cout<< calcAvgRating("The Sisterhood of the Travelling Pants", )
}

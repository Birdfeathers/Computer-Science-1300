#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

int readBooks(string file_name, string titles[], string authors[], int numbooks, int capacity)
{
    ifstream readbook;
    readbook.open(file_name);
    if(!readbook.is_open()) return -1;
    string line;
    int booknumber = numbooks;
    while(getline(readbook,line) && booknumber < capacity)
    {
        int linelength = line.length();
        string author= "", title= "";
        int i = 0;
        for(i; line[i] != ','; i++)
        {
            author = author + line[i];
        }
        for(i++; i < linelength; i++)
        {
            title = title + line[i];
        }
        authors[booknumber] = author;
        titles[booknumber]= title;
        booknumber++;
    }
    return booknumber;
}

void printAllBooks(string titles[], string authors[], int numbooks)
{
    if(numbooks == 0) cout<< "No books are stored";
    else
    {
        cout<< "Here is a list of books"<<endl;
        for(int i=0; i < numbooks; i++)
        {
            cout << titles[i] << " by " << authors[i] << endl;
        }
    }
}

int main()
{
    string titles[]= { "Earth", "Air", "Fire", "Water"};
    string authors[]={ "horse", "Eagle", "Salamander","Dolphin"};
    printAllBooks(titles, authors, 4);
}
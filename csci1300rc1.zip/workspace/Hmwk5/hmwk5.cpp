// CSCI1300 Fall 2018
// Author: Rebecca Carr
// Recitation: 108 - Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Homework 5

#include <iostream>
#include <string>
using namespace std;
/* Algorithm: find the best match:
In function simScore:
1. take in sequence 1 and sequence 2
2. set variable length to the length of sequence 1
3. If the length of sequence 1 does not equal length of sequence 2 return 0.
4. If the length of sequence 1 equals zero return zero.(sequence 2 will also be 0 in this case)
5. create a variable for hamming distance and set it equal to 0.
6. create a loop that repeats the until a counter starting at zero and increasing once each execution equls zero
Within the loop:
    a. if the character in the position equal the counter in one string does not equal the one in the other add one to hamming distance
7. find the similarity score using the formula: similarity_score = (length - hamming_distance) / length;
8. return the similarity score.

In function geneto unknown:
0. accept arguments for the string of a genome, the string of an unknown genome, and the lengths of each.
1. create variable my Substring.
2. create variable highsim for highest similarity score. Set it to zero.
3. create a loop that:
    a. sarts when an integer counter is set to zero
    b. continues until the counter equals the length of the genome minus the length of the unknown genome plus 1
    c. increases the counter with each exection
    each time the loop executes it will:
    a. set mySubstring equal to a substring of the genome starting at the index equal to the counter with the length of the unknown strand
    b. create the variable score and set it equal to the value returned by function Similarity score with the arguments of the mySubstring and the unknown strand.
    c. if the score is higher than the current highsim, set highsim equal to the score
4. return the highsim.(highest similarity score for the loop)

In function analyzer:
0. accept variables for three known genomes and an unknown genome.
1. Set the varaible length equal to the length of genome1, the variable length2 equal to length of genome2, and the variable 
length3 equal the length of genome 3. 
2. set the variable ulength equal to the length of the unknown sequence.
3. if any of the above variables equal zero, print "Genome and sequence cannot be empty."
4. otherwise, if the three genome lengths are not equal print, "Genome length does not match."
5. otherwise, if ulength > length print "Sequence length must be smaller than genome length."
6. otherwise:
    1. set the variable highsim1 equal to the value returned by function genetounknown called with the arguments:gene1,
    unknown, length and ulength
    2. set the variable highsim2 equal to the value returned by function genetounknown called with the arguments:gene2,
    unknown, length and ulength
    3. set the variable highsim3 equal to the value returned by function genetounknown called with the arguments:gene3,
    unknown, length and ulength
    4. If highsim1 is greater than or equal to highsim2 and highsim3
            print "Genome 1 is the best match."
    5. If highsim2 is greater than or equal to highsim1 and highsim3
            print "Genome 2 is the best match."
    6. If highsim3 is greater than or equal to highsim2 and highsim1
            print "Genome 3 is the best match."

*/

double simScore(string sequence1, string sequence2)// returns similarity of 2 strings of equal length
{
    double length = sequence1.length();
    if (length != sequence2.length()) return 0; // edge case, diff lengths return 0
    if (length == 0) return 0; // in this case both lengths equal zero
    int i = 0, hamming_distance = 0; // number of differences b/w two strings
    for (i; i < length ; i++)
    {
        if(sequence1[i] != sequence2[i])hamming_distance++; // compares each character in one string to the other in the same position
    }
    double similarity_score = (length - hamming_distance) / length;// equation for similarity score
    return similarity_score;
}

double genetounknown(string gene, string unknown,int length,int ulength) // returns the highest similarity score to the unknown strand in the genome 
{
    string mySubstring;
    double highsim = 0;
    for(int i=0; i < length-ulength +1; i++)
    {
        mySubstring = gene.substr(i,ulength); // creates a substring to compare to the unknown
        double score = simScore(mySubstring, unknown);// compares
        if (score > highsim) highsim = score; // sets it to the highest simscore
    }
    return highsim;
}

void analyzer(string gene1, string gene2, string gene3, string unknown)
{
    int length = gene1.length(),length2 = gene2.length(),length3=gene3.length();
    int ulength= unknown.length();
    if(length == 0|| length2 ==0 || length3 == 0|| ulength == 0)// if any length is zero return this message
    {
        cout << "Genome and sequence cannot be empty."<< endl;
    }
    else if(length != length2 || length != length3 )// sees if all lengths are equal, outputs message if not
    {
        cout << "Genome length does not match."<< endl;
    }
    else if (ulength > length)// prints message if the unkonwn is bigger than the sequence length
    {
        cout << "Sequence length must be smaller than genome length.";
    }
    else
    {
        double highsim1, highsim2, highsim3;
        highsim1 = genetounknown(gene1, unknown, length, ulength);// highest similarity score for genome1
        highsim2 = genetounknown(gene2, unknown, length, ulength);// highest similarity score for genome2
        highsim3 = genetounknown(gene3, unknown, length, ulength);// highest similarity score for genome3
        if(highsim1 >= highsim2 && highsim1 >= highsim3)
        {
            cout<<"Genome 1 is the best match." << endl;
        }
        if(highsim2 >= highsim1 && highsim2 >= highsim3)
        {
            cout <<"Genome 2 is the best match." << endl;
        }
        if(highsim3 >= highsim1 && highsim3 >= highsim2)
        {
            cout << "Genome 3 is the best match." << endl;// one, two, or all of these statements can be printed
        }
        
    }
    
}

int main()
{
    cout <<simScore("ACCT", "ACCG")<<endl; //should return .75
    cout << simScore("ACCTC","ACCTC")<< endl;//should return 1
    cout <<simScore("ACCT", "CAAA")<< endl; //should return 0
    cout <<simScore("ACCT", "")<< endl; //should return 0
    cout <<simScore("", "AAAA")<< endl; //should return 0
    cout << simScore ("", "")<< endl; // should return 0
    cout << simScore("CAA", "CAAT")<< endl; // should return 0
    
    cout << genetounknown("AAAA", "A", 4, 1 )<< endl;// should return 1
    cout << genetounknown("LOIP", "UK", 4, 2)<<endl;// should return 0
    cout << genetounknown("IILP", "LOOP", 4, 4)<< endl; // should return .25
    cout << genetounknown("JKILT", "KILL", 5, 4)<<endl; // should return .75
    cout << genetounknown("OOO", "OOP", 3,3)<< endl; // should return .67
    cout << genetounknown("12345JJIT10LITTER", "JITLITTER",17, 9)<<endl;// should return .67;
    
    analyzer("TUAAAATUAA", "CCCCCCGGAA","TTTTTTGGAA", "AAAA"); // should print "Genome 1 is the best match"
    analyzer("UAAA", "UARR", "TUAR", "UAR"); // should print both Genome 2 is best and Genome 3 is best
    analyzer("POUPY", "OOUOP","KPQPL","POP"); // should print Genome 1, 2, and 3 best
    analyzer("", "LLL", "LLL", "LLL");//should print sequence cannot be empty
    analyzer("I", "L","U", ""); //should print sequence cannot be empty
    analyzer("IUT", "LLLL", "KK", "O"); //should print Genome length does not match
    analyzer("III", "JJJ", "KKK", "OLOLO"); //should print sequence greater than genome
}

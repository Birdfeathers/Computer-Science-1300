#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int main()
{
    ofstream outfile;
   outfile.open("My.txt");
   outfile << "This text is to be inserted!" << endl << "This is also to be inserted!!!" << endl;
   outfile.close();
}
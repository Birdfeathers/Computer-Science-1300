#include <iostream>
#include <string>
using namespace std;

int CountVowels(string str)
{
    int length = str.length();
    if(length == 0) return -1;
    int numvowels = 0;
    for(int i= 0; i < length ; i++)
    {
       if(str[i]=='i'|| str[i] == 'e' || str[i] == 'o' || str[i] == 'u' || str[i]
       == 'a') numvowels++;
        if(str[i]=='I'|| str[i] == 'E' || str[i] == 'O' || str[i] == 'U' || str[i]
       == 'A') numvowels++;
    }
    return numvowels;
}

int main()
{
    cout << CountVowels("One1, Two2") << endl;
}
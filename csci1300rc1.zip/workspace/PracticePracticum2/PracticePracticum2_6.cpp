#include <iostream>
#include <string>
using namespace std;

void MultiplicationTableWhile()
{
    int i= 1;
    while( i < 6)
    {
        int j = 1;
        while( j <= i)
        {
            cout<< i * j <<" ";
            j++;
        }
        i++;
        cout<< endl;
    }
}

int main()
{
    MultiplicationTableWhile();
}
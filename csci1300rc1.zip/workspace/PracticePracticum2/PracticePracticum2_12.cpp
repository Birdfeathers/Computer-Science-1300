#include <iostream>
#include <string>
using namespace std;

string ReplaceHashTag(string str)
{
  int length = str.length();
  string str2 = "";
  for(int i = 0; i< length; i++ )
  {
      if(str[i] != '#') str2= str2 + str[i];
      else str2 = str2 + '@';
  }
  return str2; 
}

int main()
{
   cout<<ReplaceHashTag("hhhh# ioj"); 
}
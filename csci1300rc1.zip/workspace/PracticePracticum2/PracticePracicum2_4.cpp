#include <iostream>
#include <string>
using namespace std;

bool IsPrime(int number)
{
   bool truthValue = true;
   if(number < 2) truthValue = false;
   for(int i = 2; i < number; i++)
   {
       if(number % i == 0)truthValue = false;
   }
   return truthValue;
}

int main()
{
    cout << IsPrime(3) << endl;
    cout << IsPrime(4) << endl;

}
#include <iostream>
#include <string>
using namespace std;

void PrintNonLetters(string str)// prints non capital/lowercase letters
{
   int length= str.length();
   bool arenondigits = false;
   for(int i = 0; i < length ; i++) 
   {
       if(str[i] < 65 || (str[i] > 90 && str[i] < 97)|| str[i] > 122)
       {
           cout << str[i];
           arenondigits= true;
       }
   }
   if(length== 0) cout<< "NULL";
   else if(arenondigits == false) cout << -2;
}

int main()
{
    PrintNonLetters("one1, two2");
    PrintNonLetters("Test3: 2 String.");
}
#include <iostream>
#include <string>
using namespace std;

bool IsAllAlpha(string str)
{
    bool truthValue = true;
    int length = str.length();
    for(int i = 0; i < length ; i++)
    {
        if(str[i]< 65) truthValue = false;
        if(str[i]> 90 && str[i] < 97) truthValue = false;
        if(str[i] > 122) truthValue = false;
    }
    return truthValue;
}

int main()
{
    cout << IsAllAlpha("ONE") << endl;
    cout << IsAllAlpha("ONETWO2") << endl;
}
#include <iostream>
#include <string>
using namespace std;

void MultiplicationTableFor()
{
    for(int i = 1; i < 6; i++)
    {
        for(int j = 1; j<= i; j++)
        {
            cout<< i * j <<" ";
        }
        cout<< endl;
    }
}

int main()
{
    MultiplicationTableFor();
}
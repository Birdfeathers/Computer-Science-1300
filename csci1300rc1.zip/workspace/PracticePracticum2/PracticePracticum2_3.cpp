#include <iostream>
#include <string>
using namespace std;

 bool IsAllLower(string str)
 {
    bool truthValue = true;
    int length = str.length();
    for(int i = 0; i < length ; i++)
    {
        if(str[i] < 97 || str[i] > 122)truthValue = false;
    }
    return truthValue;
 }
 
 int main()
 {
    cout << IsAllLower("OneTwo") << endl;
    cout << IsAllLower("onetwo") << endl;
 }
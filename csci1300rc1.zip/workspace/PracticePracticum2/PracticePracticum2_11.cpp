#include <iostream>
#include <string>
using namespace std;

string RemoveHashTag(string str)
{
  int length = str.length();
  string str2 = "";
  for(int i = 0; i< length; i++ )
  {
      if(str[i] != '#') str2= str2 + str[i];
  }
  return str2;
}

int main()
{
    cout<<RemoveHashTag("hhhh# ioj");
}
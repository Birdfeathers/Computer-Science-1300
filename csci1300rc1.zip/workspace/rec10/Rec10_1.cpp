#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

void modifyVector(vector<int>&v)
{
        int value = 1;
        while(value > 0)
        {
            cout << "Please enter an integer value:"<<endl;
            cin >> value;
            if(value <= 0);
            else if( v.size() == 0)
            {
                v.push_back(value);
            }
            else if(value % 5 ==0)
            {
                v.erase(v.begin() + 0);
            }
            else if(value % 3 == 0)
            {
                v.pop_back();
            }
            else
            {
                v.push_back(value);
            }
        }
    
}

int main()
{
    vector<int> v;
    modifyVector(v);
    for(int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
}
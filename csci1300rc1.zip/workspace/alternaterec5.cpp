#include <iostream>
#include <string>
using namespace std;

int getMatchCount(string sub, string large)
{
    int length = large.length();
    int sublength = sub.length();
    if (sublength==0|| length== 0) return -1;
    if (sublength > length) return -2;
    int matches = 0;
    string mySubstring;
    int i = 0;
    for(i=0; i < (length - sublength + 1); i++)
    { 
     mySubstring = large.substr(i, sublength);
     if(mySubstring == sub) matches ++;
    }
    return matches;
    
}

int main()
{
    cout<< getMatchCount("yo", "yoyo")<<endl;
    cout << getMatchCount("si", "Mississippi")<<endl;
    cout << getMatchCount("re", "rrrrrrerererereredo")<<endl;
}
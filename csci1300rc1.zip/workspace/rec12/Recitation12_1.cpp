#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

string reversestring(string string1)
{
    string string2 = "";
    for(int i = string1.length(); i > 0; i--)
    {
        string2 = string2 + string1[i - 1];
    }
    return string2;
}

string decimalToBinaryIterative(int numconvert)
{
    int numremaining = numconvert;
    string binarynumber = "";
    if(numconvert == 0) return "0";
    while(numremaining > 0)
    {
        int remainder = numremaining % 2;
        if(remainder == 0) binarynumber = binarynumber + "0";
        else binarynumber = binarynumber + "1";
        numremaining = numremaining /2;
    }
    return reversestring(binarynumber);
}

string decimalToBinaryRecursive(int numconvert)
{
    string binarynumber = "";
    if(numconvert == 0) return "0";
    int numremaining = numconvert;
    if(numremaining == 0){
        return binarynumber;
    }
    else{
        int remainder = numremaining % 2;
        if(remainder == 0) binarynumber = binarynumber + "0";
        else binarynumber = binarynumber + "1";
        numremaining = numremaining /2;
        return decimalToBinaryRecursive(numremaining) + binarynumber;
    }
}

int main()
{
    cout << decimalToBinaryIterative(1) <<endl;
    cout << decimalToBinaryIterative(10) <<endl;
    cout << decimalToBinaryIterative(512) <<endl;
    cout <<"-----" << endl;
    cout << decimalToBinaryRecursive(8) <<endl;
    // cout << decimalToBinaryRecursive(10) <<endl;
    // cout << decimalToBinaryRecursive(512) <<endl;
}
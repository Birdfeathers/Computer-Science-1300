#include <iostream>
using namespace std;

int main()
{
    bool x;
    int a, b, c;
    a= 0;
    b=11;
    c= 7;
    
    x= (0 <= b) && (b < 12);
    cout << x;
}
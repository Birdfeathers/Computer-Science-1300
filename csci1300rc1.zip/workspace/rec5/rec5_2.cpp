// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 5 - Problem # 2

#include <iostream>
using namespace std;

int getDigitCount(string letters)
{
    int length = letters.length();
    int number = 0;
    int digits = 0;
    while(number < length)
    {
        if(isdigit(letters[number])) digits++;
        number++;
    }
    return digits;
}

int main()
{
    cout << getDigitCount("yeurh 888");
}
// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 5 - Problem # 3

#include <iostream>
#include <string>
using namespace std;

int getMatchCount(string sub, string large)
{
    int length = large.length();
    int sublength = sub.length();
    if (sublength==0|| length== 0) return -1;
    if (sublength > length) return -2;
    int number = 0;
    int matches = 0;// number of segments that match
    while(number < length)
    {
        if(large[number] == sub[0]);
        {
            int start = number;
            int matcher = 0;//number we're checking
            int charmatch=0;
            while(matcher < sublength)
            {
                if(large[start] == sub[matcher]) charmatch ++;
                matcher++;
                start++;
            }
            if(charmatch == sublength) matches ++;
        }
        number++;
    }
    return matches;
}

int main()
{
    cout << getMatchCount("si", "Mississippi")<<endl;
    cout << getMatchCount("s", "Mississippi")<<endl;
    cout << getMatchCount("re", "rrrrrrerererereredo")<<endl;
    cout << getMatchCount("sip", "Mississippis")<<endl;
}
// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 5 - Problem # 1

#include <iostream>
using namespace std;

int getWordCount(string sentence)
{
    int length = sentence.length();
    if(length == 0) return 0;
    int number = 0;
    int spaces = 0;
    while(number <= length)
    {
        if(sentence[number] == ' ') spaces++;
        number++;
    }
    int words = spaces + 1;
    return words;
}

int main()
{
   cout << getWordCount("go go go")<<endl ;
   cout << getWordCount("");
}
// Rebecca Carr : CS1300 Fall 2018
// Recitation: 108 – Isabella Huang
// Cloud9 Workspace Editor Link: https://ide.c9.io/birdfeathers/csci1300rc
// Recitation 5 - Problem # 4

#include <iostream>
using namespace std;

int getLastIndex(char letter, string word)
{
    int length = word.length();
    if(length == 0) return -1;
    int index = -2;
    int number = 0;
    while(number < length)
    {
        if(word[number]== letter) index = number;
        number++;
    }
    return index;
}

int main()
{
    cout << getLastIndex('o', "lollipop")<<endl;
    cout << getLastIndex('p', "Mississippi")<<endl;
    cout<< getLastIndex('p', "")<<endl;
    cout <<getLastIndex('p', "iii")<<endl;
}
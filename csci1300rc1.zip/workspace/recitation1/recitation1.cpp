#include <iostream>
using namespace std;

int main() {
    int number;
    std::cout <<"Enter a CS course number"<<endl;
    cin>> number;
    std::cout <<"Hello, CS "<<number<<" World!"<<endl;
}

#include <iostream>
#include <math.h>
using namespace std;

void sphereSurfaceArea (float radius)
{
    float surface_area = 4 * M_PI * radius * radius;
    cout << "surface area: " << surface_area << endl;
}

int main(){
    sphereSurfaceArea(5);
   
}
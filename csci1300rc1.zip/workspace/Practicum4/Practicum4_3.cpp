#include <iostream>
using namespace std;
#include <string>
#include <fstream>
#ifndef AWARDWINNERS
#define AWARDWINNERS

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

class AwardWinners
{
    public:
        AwardWinners();
        int ReadFile(string filename);
        string getWinnerName(int winningYear);
        int getWinningYear(string winner);
    private:
        string name[20];
        int year[20];
};
#endif

AwardWinners :: AwardWinners()
{
    for(int i = 0; i < 20; i++)
    {
        name[i] = "";
        year[i] = 0;
    }
}

int AwardWinners :: ReadFile(string filename)
{
    ifstream file;
    file.open(filename);
    string line;
    string array1[2];
    if(!file.is_open()) return -1;
    else{
        for(int i= 0; i < 20; i++)
        {
            if(getline(file, line))
            {
                split(line, '@', array1, 2);
                name[i] = array1[0];
                year[i] = stoi(array1[1]);
            }
        }
    }
    return 0;
}

int findYear(int winningYear, int year[20])
{
    for(int i = 0; i < 20; i++)
    {
        if(year[i] == winningYear) return i;
    }
    return -1;
}

string AwardWinners :: getWinnerName(int winningYear)
{
    if(findYear(winningYear, year) == -1) return "";
    return name[findYear(winningYear,year)];
}

int findname(string winner, string name[20])
{
    for(int i = 0; i < 20; i++)
    {
        if(name[i] == winner) return i;
    }
    return -1;
}
int AwardWinners :: getWinningYear(string winner)
{
    if(findname(winner, name) == -1) return -1;
    return year[findname(winner, name)];
}

int main()
{
    AwardWinners one;
    one.ReadFile("txt.txt");
    cout << one.getWinnerName(2002) <<endl;
    cout << one.getWinningYear("Tim Berners-Lee") <<endl;
    cout << one.ReadFile("k") <<endl;
}
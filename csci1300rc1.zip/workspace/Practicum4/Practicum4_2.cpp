#include <iostream>
using namespace std;
#ifndef CITY
#define CITY

class City
{
    public:
        City();
        City(string n, int p);
        string getName();
        int getPopulation();
        void setName(string n);
        void setPopulation(int p);
        string category();
    private:
        string name;
        int population;
};
#endif

City :: City()
{
    name = "";
    population = 0;
}
City :: City(string n, int p)
{
    name = n;
    population = p;
}
string City :: getName()
{
    return name;
}
int City :: getPopulation()
{
   return population; 
}
void City :: setName(string n)
{
    name = n;
}
void City :: setPopulation(int p)
{
    population = p;
}
string City :: category()
{
if(population <= 2000) return "Village";
if(population <= 10000) return "Town";
if(population <= 50000) return "City";
if(population <= 100000) return "Capital";
if(population <= 500000) return "Metropolis";
return "Megalopolis";
}

int main()
{
    City one("n", 50000);
    cout << one.category() <<endl;
}

